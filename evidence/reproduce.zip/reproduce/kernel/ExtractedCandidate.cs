using System;
using System.Threading;
namespace GRAL_2001 {
class ParticleManagement {
public static double ParticleMassActive;
public static void SetResidualParticleMass()
        {
            double emission = ActiveEmission(Program.PS_ER, Program.PS_ER_Dep, Program.PS_Mode, Program.PS_SG, Program.PS_Count)
                + ActiveEmission(Program.LS_ER, Program.LS_ER_Dep, Program.LS_Mode, Program.LS_SG, Program.LS_Count)
                + ActiveEmission(Program.TS_ER, Program.TS_ER_Dep, Program.TS_Mode, Program.TS_SG, Program.TS_Count)
                + ActiveEmission(Program.AS_ER, Program.AS_ER_Dep, Program.AS_Mode, Program.AS_SG, Program.AS_Count);
            if (emission > 0)
            {
                ParticleMassActive = emission / 3600 / Program.TPS * 1000000000 / Program.GridVolume / Program.TAUS;
            }
            else if (ParticleMassActive <= 0)
            {
                ParticleMassActive = Program.ParticleMassMean;
            }
        }
private static double ActiveEmission(double[] rates, float[] depositionRates, byte[] modes, byte[] groups, int count)
        {
            double emission = 0;
            for (int i = 1; i <= count; i++)
            {
                if (rates[i] <= 0 || (modes[i] == Consts.DepoOnly && depositionRates[i] <= 0))
                {
                    continue;
                }
                int group = Program.SourceGroups.IndexOf(groups[i]);
                if (Program.EmissionTimeseriesExist && Program.IWET > 0 &&
                    Program.IWET <= Program.EmFacTimeSeries.GetUpperBound(0) &&
                    group >= 0 && group <= Program.EmFacTimeSeries.GetUpperBound(1) &&
                    Program.EmFacTimeSeries[Program.IWET - 1, group] <= 0)
                {
                    continue;
                }
                emission += rates[i];
            }
            return emission;
        }
}
class ZeitschleifeNonSteadyState {
private static double residualSplitK = 10;
private static int ResidualSplitCount(double masse)
        {
            return (int)Math.Min(100000,
                Math.Floor(masse / (ParticleManagement.ParticleMassActive * residualSplitK)) + 1);
        }
public static void PlanResidual()
        {
            if (Program.CancelToken.IsCancellationRequested) return;
            residualSplitK = 10;
            double budget = Program.TAUS * Program.TPS;
            if (budget <= 0 || ParticleManagement.ParticleMassActive <= 0)
            {
                return;
            }
            for (int it = 0; it < 6; it++)
            {
                long total = 0;
                System.Threading.Tasks.Parallel.For(1, Program.NII + 1, Program.pOptions, i =>
                {
                    if (Program.CancelToken.IsCancellationRequested) return;
                    long local = 0;
                    for (int j = 1; j <= Program.NJJ; j++)
                    {
                        for (int k = 1; k <= Program.NKK_Transient; k++)
                        {
                            double volume = Program.DXK * Program.DYK * Program.DZK_Trans[k] / Program.GridVolume;
                            float[] concentrations = Program.Conz4d[i][j][k];
                            for (int group = 0; group < Program.SourceGroups.Count; group++)
                            {
                                if (concentrations[group] >= Program.TransConcThreshold)
                                {
                                    local += ResidualSplitCount(concentrations[group] * volume / Program.TAUS);
                                }
                            }
                        }
                    }
                    Interlocked.Add(ref total, local);
                });
                if (Program.CancelToken.IsCancellationRequested) return;
                if (total <= budget) break;
                residualSplitK *= Math.Max(1.05, total / budget);
            }
        }
 public static int Count(double m) => ResidualSplitCount(m);
public static double K => residualSplitK;
public static void ResetK() { residualSplitK = 10; }
}
}
