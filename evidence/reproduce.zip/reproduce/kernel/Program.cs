using System.Text.Json;
namespace GRAL_2001 {
static class Consts { public const byte DepoOnly = 2; }
static class Program {
 public static double TAUS=1,TPS=1,GridVolume=1000000000.0/3600;
 public static double ParticleMassMean=26;
 public static int IWET=1,NII=1,NJJ=1,NKK_Transient=1;
 public static float DXK=1,DYK=1,TransConcThreshold=0;
 public static float[] DZK_Trans=new float[]{0,1};
 public static List<int> SourceGroups=new(){0,1,2,3};
 public static float[,] EmFacTimeSeries=new float[3,4];
 public static bool EmissionTimeseriesExist=true;
 public static double[] PS_ER=new double[]{0,1},LS_ER=new double[]{0,2},TS_ER=new double[]{0,3},AS_ER=new double[]{0,20};
 public static float[] PS_ER_Dep=new float[]{0,1},LS_ER_Dep=new float[]{0,1},TS_ER_Dep=new float[]{0,1},AS_ER_Dep=new float[]{0,1};
 public static byte[] PS_Mode=new byte[]{0,0},LS_Mode=new byte[]{0,0},TS_Mode=new byte[]{0,0},AS_Mode=new byte[]{0,0};
 public static byte[] PS_SG=new byte[]{0,0},LS_SG=new byte[]{0,1},TS_SG=new byte[]{0,2},AS_SG=new byte[]{0,3};
 public static int PS_Count=1,LS_Count=1,TS_Count=1,AS_Count=1;
 public static float[][][][] Conz4d;
 public static System.Threading.CancellationTokenSource CancelToken = new();
 public static System.Threading.Tasks.ParallelOptions pOptions = new() { MaxDegreeOfParallelism = 1 };
 static int checks=0;
 static void Check(bool ok,string name) { checks++; if(!ok) throw new Exception(name); }
 static int Old(double m,double mass) { int r=(int)(m/mass); return r/10+1; }
 static int C1(double m,double mass) => (int)Math.Min(100000,
                Math.Floor(Math.Floor(m / mass) / 10) + 1);
 static void Factors(float a,float b,float c,float d) { EmFacTimeSeries[0,0]=a;EmFacTimeSeries[0,1]=b;EmFacTimeSeries[0,2]=c;EmFacTimeSeries[0,3]=d; }
 static void Grid(float[] masses,double budget) {
  NII=masses.Length;NJJ=1;NKK_Transient=1;SourceGroups=new(){0};TAUS=1;TPS=budget;GridVolume=1;ParticleManagement.ParticleMassActive=1;TransConcThreshold=0;
  Conz4d=new float[NII+1][][][];
  for(int i=1;i<=NII;i++) { Conz4d[i]=new float[2][][];Conz4d[i][1]=new float[2][];Conz4d[i][1][1]=new float[]{masses[i-1]}; }
 }
 static object Budget(float[] masses,double budget) {
  Grid(masses,budget);ZeitschleifeNonSteadyState.ResetK();int before=masses.Sum(x=>ZeitschleifeNonSteadyState.Count(x));
  ZeitschleifeNonSteadyState.PlanResidual();int after=masses.Sum(x=>ZeitschleifeNonSteadyState.Count(x));
  return new {entries=masses.Length,budget,initial_count=before,final_count=after,final_k=ZeitschleifeNonSteadyState.K,meets_target=after<=budget};
 }
 static void Main(string[] args) {
  var data=new Dictionary<string,object>();
  Factors(1,0,0,0);ParticleManagement.ParticleMassActive=0;ParticleManagement.SetResidualParticleMass();Check(ParticleManagement.ParticleMassActive==1,"binary active reference");
  data["reference_example"]=new {reference_mass=26,active_reference_mass=ParticleManagement.ParticleMassActive,residual_mass=100,k=10,before=Old(100,26),after=C1(100,ParticleManagement.ParticleMassActive)};
  Factors(0.2f,0,0,0);ParticleManagement.SetResidualParticleMass();Check(ParticleManagement.ParticleMassActive==1,"positive factor magnitude ignored");
  data["nonbinary_factor"]=new {positive_factor=0.2f,active_reference_mass=ParticleManagement.ParticleMassActive,factor_weighted_reference_mass=(double)0.2f,actual_fresh_mean_not_computed=true,source_allocation_unchanged=true};
  Factors(0,0,0,0);ParticleManagement.SetResidualParticleMass();Check(ParticleManagement.ParticleMassActive==1,"all off retains previous");
  data["all_off_previous"]=ParticleManagement.ParticleMassActive;
  ParticleManagement.ParticleMassActive=0;ParticleManagement.SetResidualParticleMass();Check(ParticleManagement.ParticleMassActive==26,"initial all off fallback");
  data["all_off_initial"]=ParticleManagement.ParticleMassActive;
  Factors(1,1,1,1);ParticleManagement.SetResidualParticleMass();Check(ParticleManagement.ParticleMassActive==26,"four source kinds sum");
  PS_Mode[1]=Consts.DepoOnly;PS_ER_Dep[1]=0;ParticleManagement.SetResidualParticleMass();Check(ParticleManagement.ParticleMassActive==25,"inactive deposition-only omitted");PS_Mode[1]=0;PS_ER_Dep[1]=1;
  EmissionTimeseriesExist=false;Factors(0,0,0,0);ParticleManagement.SetResidualParticleMass();Check(ParticleManagement.ParticleMassActive==26,"missing timeseries uses all");EmissionTimeseriesExist=true;
  int disagreements=0;var examples=new List<object>();var rng=new Random(7023);
  for(int n=0;n<200000;n++) { double mass=Math.Pow(10,rng.NextDouble()*20-10);double ratio=rng.NextDouble()*999999;double m=ratio*mass;int old=Old(m,mass);int c=C1(m,mass);if(old!=c){disagreements++;if(examples.Count<10)examples.Add(new{m,mass,old,c});} }
  for(int n=1;n<=10000;n++) { double mass=Math.Pow(10,rng.NextDouble()*20-10);double m=(10.0*n)*mass;int old=Old(m,mass);int c=C1(m,mass);if(old!=c){disagreements++;if(examples.Count<10)examples.Add(new{m,mass,old,c});} }
  data["ordinary_equivalence_sweep"]=new{cases=210000,disagreements,examples}; Check(disagreements==0,"preserve ordinary split thresholds");
  data["large_ratio"]=new[]{new{residual_mass=1e9,reference_mass=1.0,unlimited_real_split=100000001.0,original_integer_split=Old(1e9,1),candidate_split=C1(1e9,1)},new{residual_mass=1e10,reference_mass=1.0,unlimited_real_split=1000000001.0,original_integer_split=Old(1e10,1),candidate_split=C1(1e10,1)}};
  Check(C1(1e9,1)==100000,"per entry cap");Check(C1(1e10,1)==100000,"overflow capped before cast");Check(C1(double.PositiveInfinity,1)==100000,"positive infinity capped");
  Check(C1(0,1)==1,"zero ratio minimum one");Check(C1(9.99,1)==1,"below threshold");Check(C1(10,1)==2,"threshold ten");
  data["budget_feasible"]=Budget(Enumerable.Repeat(100f,100).ToArray(),200);Check(ZeitschleifeNonSteadyState.K==55,"feasible k55");Check(Enumerable.Repeat(100f,100).Sum(x=>ZeitschleifeNonSteadyState.Count(x))==200,"feasible count200");
  data["budget_floor_impossible"]=Budget(Enumerable.Repeat(0.01f,300).ToArray(),200);Check(Enumerable.Repeat(0.01f,300).Sum(x=>ZeitschleifeNonSteadyState.Count(x))==300,"eligible floor300");
  data["budget_six_pass_overshoot"]=Budget(new float[]{1000000}.Concat(Enumerable.Repeat(1f,999)).ToArray(),1001);Check(ZeitschleifeNonSteadyState.K>0,"positive final k");Check(Conz4d.Skip(1).Sum(x=>ZeitschleifeNonSteadyState.Count(x[1][1][0]))==1167,"feasible budget overshoot1167");
  Grid(new float[]{100,0.01f},100);TransConcThreshold=1;ZeitschleifeNonSteadyState.PlanResidual();Check(ZeitschleifeNonSteadyState.K==10,"threshold excludes low entry");
  float c100=100,norm=c100/11;double reconstructed=norm*11.0;float subnormal=float.Epsilon/2;
  data["float_mass_rounding"]=new{concentration=c100,split_count=11,per_split_concentration=norm,reconstructed,relative_error=(reconstructed-c100)/c100,subnormal_before=float.Epsilon,subnormal_split_count=2,subnormal_per_split=subnormal,subnormal_reconstructed=(double)subnormal*2,mathematical_conservation_only=true};
  Check(Math.Abs((reconstructed-c100)/c100)<1e-7,"ordinary float rounding");Check(subnormal==0,"subnormal underflow remains");
  data["checks_passed"]=checks;data["scope"]="Extracted candidate methods plus arithmetic fixtures. No GRAL Main, plume, concentration or speed simulation.";
  File.WriteAllText(args[0],JsonSerializer.Serialize(data,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine("checks "+checks+" disagreements "+disagreements);
 }
}
}
