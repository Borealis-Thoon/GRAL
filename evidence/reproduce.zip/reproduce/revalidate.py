"""Rebuild the six separated residual candidates and replay a short synthetic suite."""
from __future__ import annotations
import argparse,gzip,hashlib,json,math,os,re,shutil,signal,struct,subprocess,sys,time,zipfile
from pathlib import Path
NAMES=['warning_free_baseline','seed_only','C1_safe_split_limit','C1_standalone','C2_active_reference','C3_adaptive_budget']
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def method(text,start):
    a=text.index(start);b=text.index('{',a);depth=1;c=b+1
    while depth:
        if text[c]=='{':depth+=1
        elif text[c]=='}':depth-=1
        c+=1
    return text[a:c]
def normalized_source_hash(path):return hashlib.sha256(path.read_text(encoding='utf-8-sig').replace('\r\n','\n').encode('utf-8')).hexdigest()
def inspect_inputs_and_sources(package,sources):
    manifest=json.loads((package/'qa/source_manifest.json').read_text(encoding='utf-8'))
    for name in NAMES:
        actual={p.relative_to(sources[name]).as_posix():normalized_source_hash(p) for p in sorted((sources[name]/'src').glob('*.cs'))}
        if actual!=manifest['variants'][name]['source_files']:raise AssertionError('Source manifest differs: '+name)
    for n in (100,1000,3000):
        template=package/'inputs'/f'budget{n}_fixed';inputs=json.loads((template/'input_manifest.json').read_text(encoding='utf-8'))
        for name,record in inputs.items():
            if digest(template/name)!=record['sha256']:raise AssertionError('Input manifest differs: '+str(template/name))
    c3=sources['C3_adaptive_budget']/'src';fixture=(package/'reproduce/kernel/ExtractedCandidate.cs').read_text(encoding='utf-8')
    for file,begin in [('TeilchenAufteilung.cs','public static void SetResidualParticleMass()'),('TeilchenAufteilung.cs','private static double ActiveEmission('),('Zeitschleife_nonsteadystate.cs','private static int ResidualSplitCount('),('Zeitschleife_nonsteadystate.cs','public static void PlanResidual()')]:
        if method((c3/file).read_text(encoding='utf-8-sig'),begin) not in fixture:raise AssertionError('Extracted method differs: '+begin)
    runtime=(package/'reproduce/runtime/ExtractedCandidate.cs').read_text(encoding='utf-8')
    runtime=runtime.replace('                    Program.EnterRow();\n','').replace('                    Program.ExitRow();\n','')
    if method((c3/'Zeitschleife_nonsteadystate.cs').read_text(encoding='utf-8-sig'),'public static void PlanResidual()') not in runtime:raise AssertionError('Runtime fixture differs beyond row witnesses')
    for name in ('C1_standalone','C1_safe_split_limit'):
        source=(sources[name]/'src/Zeitschleife_nonsteadystate.cs').read_text(encoding='utf-8-sig')
        expression=re.search(r'int transParticlesSplit = ([\s\S]*?);',source).group(1).replace('masse','m').replace('Program.ParticleMassMean','mass')
        if expression not in (package/'reproduce/kernel/Program.cs').read_text(encoding='utf-8'):raise AssertionError('C1 expression differs: '+name)
    with gzip.open(package/'qa/reference_fixed.json.gz','rt',encoding='utf-8') as f:references=json.load(f)['runs']
    if len(references)!=28:raise AssertionError('Reference count')
    return {x['run_id']:x for x in references}
def process(command,cwd,env,timeout):
    options={'creationflags':getattr(subprocess,'CREATE_NO_WINDOW',0)} if os.name=='nt' else {'start_new_session':True}
    p=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**options)
    try:out,err=p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name=='nt':subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        else:os.killpg(p.pid,signal.SIGKILL)
        p.communicate(timeout=10);raise TimeoutError('Own process exceeded '+str(timeout)+' seconds')
    return p.returncode,out.decode('utf-8',errors='replace'),err.decode('utf-8',errors='replace')
def output_hashes(folder):
    fields=[];checkpoints=[]
    for path in sorted(folder.glob('*.grz')):
        with zipfile.ZipFile(path) as z:
            for name in sorted(z.namelist()):
                if not name.endswith('.con'):continue
                raw=z.read(name);header,x,y,dx,dy,nx,ny=struct.unpack_from('<iiiffii',raw)
                if header!=-3 or nx!=10 or ny!=10 or len(raw)!=28+nx*ny*4:raise AssertionError('Unexpected concentration header')
                values=struct.unpack_from('<'+str(nx*ny)+'f',raw,28)
                if not all(math.isfinite(v) and v>=0 for v in values):raise AssertionError('Invalid concentration')
                match=re.fullmatch(r'(\d{5})-1(\d{2})\.con',name)
                if not match:raise AssertionError('Unexpected concentration name')
                fields.append({'situation':int(match.group(1)),'sg':int(match.group(2)),'payload_sha256':hashlib.sha256(raw).hexdigest(),'sum':math.fsum(values)})
    if [(f['situation'],f['sg']) for f in fields]!=[(s,g) for s in (1,2,3) for g in (1,2)]:raise AssertionError('Expected six concentration payloads')
    for path in sorted(folder.glob('Transient_Concentrations*.tmp')):
        with zipfile.ZipFile(path) as z:checkpoints.extend(hashlib.sha256(z.read(n)).hexdigest() for n in sorted(z.namelist()))
    if len(checkpoints)!=1:raise AssertionError('Expected one stored residual checkpoint')
    return fields,checkpoints
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--package-root',type=Path,default=Path(__file__).resolve().parents[1])
    ap.add_argument('--source-root',type=Path,help='Parent of the six source trees named in qa/source_manifest.json.')
    ap.add_argument('--source-map',type=Path,help='JSON object mapping the six variant names to checkout directories.')
    ap.add_argument('--run-dir',type=Path,help='New isolated directory outside the package and source checkouts.')
    ap.add_argument('--dotnet',default='dotnet',help='Path to the .NET CLI, or its command name on PATH.')
    ap.add_argument('--check-only',action='store_true',help='Verify input hashes, source hashes and fixture extraction without building.')
    args=ap.parse_args();package=args.package_root.resolve()
    if args.source_map:
        mapping=json.loads(args.source_map.read_text(encoding='utf-8'));mapping_dir=args.source_map.resolve().parent
        sources={n:(Path(p) if Path(p).is_absolute() else mapping_dir/Path(p)).resolve() for n,p in mapping.items()}
    elif args.source_root:sources={n:args.source_root.resolve()/n for n in NAMES}
    else:ap.error('Specify --source-root or --source-map.')
    references=inspect_inputs_and_sources(package,sources)
    if args.check_only:print('[PASS] six source manifests, three input manifests and fixture extraction');return
    if args.run_dir is None:ap.error('--run-dir is required for a full run.')
    run=args.run_dir.resolve()
    if run.exists():raise FileExistsError('Use a new run directory.')
    if package==run or package in run.parents or any(source==run or source in run.parents for source in sources.values()):raise ValueError('Run directory must be outside the package and source checkouts.')
    run.mkdir(parents=True)
    for name in ['logs','tmp','cache','qa']:(run/name).mkdir()
    env=os.environ.copy();env.update({'DOTNET_CLI_HOME':str(run/'cache/dotnet_home'),'NUGET_PACKAGES':str(run/'cache/nuget'),'TEMP':str(run/'tmp'),'TMP':str(run/'tmp'),'DOTNET_CLI_UI_LANGUAGE':'en','DOTNET_NOLOGO':'1'})
    dotnet=str(Path(args.dotnet).resolve()) if Path(args.dotnet).is_file() else shutil.which(args.dotnet)
    if dotnet is None:raise FileNotFoundError('.NET CLI was not found.')
    builds={};start=time.perf_counter()
    def limit(seconds):
        remaining=900-(time.perf_counter()-start)
        if remaining<=0:raise TimeoutError('Suite exceeded the 15-minute limit.')
        return min(seconds,remaining)
    def build(project,label):
        command=[dotnet,'build',str(project),'-c','Release','-t:Rebuild','-v:minimal','--nologo','/p:TreatWarningsAsErrors=true']
        code,out,err=process(command,project.parent,env,limit(180));log=out+err;(run/'logs'/(label+'_build.log')).write_text(log,encoding='utf-8')
        warning=re.search(r'(\d+) Warning\(s\)',log);error=re.search(r'(\d+) Error\(s\)',log)
        if code or warning is None or error is None or int(warning.group(1)) or int(error.group(1)):raise RuntimeError('Strict build failed: '+label)
        builds[label]={'exit_code':code,'warnings':0,'errors':0};print('[BUILD] '+label+' 0 0',flush=True)
    variants={}
    for name in NAMES:
        target=run/'sources'/name;shutil.copytree(sources[name],target,ignore=shutil.ignore_patterns('bin','obj','.git'));variants[name]=target
        build(target/'src/GRAL.csproj',name)
    conditions=[(n,r,name) for n in (100,1000,3000) for r in (1,2) for name in ['warning_free_baseline','seed_only','C3_adaptive_budget','C1_standalone']]
    conditions += [(3000,r,name) for r in (1,2) for name in ['C1_safe_split_limit','C2_active_reference']]
    comparisons=[]
    for index,(budget,repeat,name) in enumerate(conditions,1):
        if time.perf_counter()-start>900:raise TimeoutError('Suite exceeded the 15-minute limit.')
        rid=f'fixed_n{budget}_{name}_r{repeat:02d}';folder=run/'virtual_runs'/rid;shutil.copytree(package/'inputs'/f'budget{budget}_fixed',folder)
        code,out,err=process([dotnet,str(variants[name]/'src/bin/Release/net10.0/GRAL.dll'),str(folder)],folder,env,limit(60))
        (folder/'console.log').write_text(out,encoding='utf-8');(folder/'stderr.log').write_text(err,encoding='utf-8');fields,checkpoints=output_hashes(folder)
        core=folder/'Logfile_GRALCore.txt';problem=folder/'Problemreport_GRAL.txt';allocations=list(map(int,re.findall(r'Using a total of (\d+) particles',out)))
        match=re.findall(r'Summarized emission rates per source group in kg\s*\n([^\n]+)\n([^\n]+)',out)
        mass={str(g):float(x) for g,x in zip([int(v) for v in re.findall(r'SG:\s*(\d+)',match[-1][0])],match[-1][1].split())} if match else {}
        checks={'exit_zero':code==0,'completion_marker':core.exists() and 'GRAL simulations finished at:' in core.read_text(encoding='utf-8-sig'),'empty_problem_report':not problem.exists() or not problem.read_text(encoding='utf-8-sig').strip(),'six_payloads':len(fields)==6,'finite_nonnegative':True,'configured_allocation':allocations==[budget],'all_off_has_carryover':sum(f['sum'] for f in fields if f['situation']==3)>0,'fresh_mass_sg1_correct':math.isclose(mass.get('1',0),30/3600,rel_tol=.006),'fresh_mass_sg2_correct':math.isclose(mass.get('2',0),60/3600,rel_tol=.006)}
        if not all(checks.values()):raise AssertionError('Main project checks failed: '+rid)
        reference=references[rid]
        if [f['payload_sha256'] for f in fields]!=reference['concentration_payload_sha256'] or checkpoints!=reference['checkpoint_payload_sha256'] or mass!=reference['fresh_mass_kg']:raise AssertionError('Fixed reference differs: '+rid)
        comparisons.append({'run_id':rid,'checks':checks,'six_concentrations_and_checkpoint_identical':True,'fresh_mass_identical':True})
        print(f'[RUN] {index}/{len(conditions)} identical',flush=True)
    for name in ('kernel','seed','runtime'):
        target=run/'fixtures'/name;shutil.copytree(package/'reproduce'/name,target)
        build(target/('SeedChecks.csproj' if name=='seed' else 'KernelFixture.csproj'),name+'_fixture')
        dll='SeedChecks.dll' if name=='seed' else 'KernelFixture.dll'
        output=run/'qa'/('seed' if name=='seed' else name+'_checks.json')
        extra=[str(variants['seed_only']/'src/bin/Release/net10.0/GRAL.dll'),str(output)] if name=='seed' else [str(output)]
        code,out,err=process([dotnet,str(target/'bin/Release/net10.0'/dll),*extra],target,env,limit(120));(run/'logs'/(name+'_fixture_run.log')).write_text(out+err,encoding='utf-8')
        if code:raise RuntimeError('Fixture failed: '+name)
    kernel=json.loads((run/'qa/kernel_checks.json').read_text());seed=json.loads((run/'qa/seed/candidate_seed_checks.json').read_text());runtime=json.loads((run/'qa/runtime_checks.json').read_text())
    if kernel['checks_passed']!=22 or kernel['ordinary_equivalence_sweep']['cases']!=210000 or kernel['ordinary_equivalence_sweep']['disagreements']!=0 or seed['checks']!=38 or seed['status']!='pass' or runtime['checks_passed']!=11:raise AssertionError('Helper summary differs.')
    metadata=json.loads((package/'qa/test_summary.json').read_text())
    if digest(run/'qa/seed/candidate_rng_draws.csv')!=metadata['seed_draw_csv_sha256']:raise AssertionError('Seed fixture differs.')
    save(run/'qa/revalidation_summary.json',{'status':'pass','candidate_strict_builds':6,'helper_strict_builds':3,'all_builds_zero_warnings_zero_errors':True,'actual_project_runs':28,'per_run_checks':252,'concentration_payloads_identical':168,'checkpoint_payloads_identical':28,'seed_helper_checks':38,'kernel_checks':22,'runtime_checks':11,'ordinary_threshold_cases':210000,'ordinary_threshold_disagreements':0,'elapsed_s':time.perf_counter()-start,'comparisons':comparisons,'builds':builds,'scope':'Fixed-seed, single-worker synthetic regression against the recorded .NET 10.0.12 results. Differences on another runtime or platform need investigation; this is not a production-domain accuracy test.'})
    print('[PASS] 28 Main runs; 71 helper checks; 210000 boundaries',flush=True)
if __name__=='__main__':main()
