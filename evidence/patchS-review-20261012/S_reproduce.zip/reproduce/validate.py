"""Verify one-file source lookup replacement using real DLLs and synthetic Main runs."""
from __future__ import annotations
import argparse,csv,difflib,hashlib,json,math,os,re,shutil,signal,struct,subprocess,sys,time,zipfile
from pathlib import Path
VARIANTS=('warning_free_baseline','patchS_minimal')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def process(command,cwd,env,timeout):
 kwargs={'creationflags':getattr(subprocess,'CREATE_NO_WINDOW',0)} if os.name=='nt' else {'start_new_session':True}
 p=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kwargs)
 try:out,err=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  if os.name=='nt':subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  else:os.killpg(p.pid,signal.SIGKILL)
  p.communicate(timeout=10);raise TimeoutError('Owned process exceeded time limit')
 return p.returncode,out.decode('utf-8',errors='replace'),err.decode('utf-8',errors='replace')
def csvwrite(path,rows):
 with path.open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def cases():
 result=[]
 for kind in ('point','portal','line','area','mixed'):
  for budget in (100,1000,3000):result.append(dict(id=f'{kind}_n{budget}',kind=kind,budget=budget,mode='stationary',sources_per_kind=1 if kind=='mixed' else 2,slices=1,receptors=False,deposition=False,odour=False,weather=[(9,1,4)]))
 result.append(dict(id='mixed_transient_schedule',kind='mixed',budget=1000,mode='transient',sources_per_kind=2,slices=1,receptors=False,deposition=False,odour=False,weather=[(9,2.5,2),(18,.5,6),(27,1,4)]))
 result.append(dict(id='many_point_n3000',kind='point',budget=3000,mode='stationary',sources_per_kind=40,slices=1,receptors=False,deposition=False,odour=False,weather=[(18,.5,6)]))
 result.append(dict(id='mixed_deposition_receptors',kind='mixed',budget=1000,mode='stationary',sources_per_kind=2,slices=1,receptors=True,deposition=True,odour=False,weather=[(18,2.5,2)]))
 result.append(dict(id='mixed_odour_multislice',kind='mixed',budget=1000,mode='stationary',sources_per_kind=2,slices=9,receptors=False,deposition=False,odour=True,weather=[(27,1,4)]))
 return result
def configure(template,folder,case):
 shutil.copytree(template,folder)
 for name in ('cadastre.dat','point.dat','portals.dat','line.dat','input_manifest.json','fixture_spec.json','synthetic_case.json'):
  if (folder/name).exists():(folder/name).unlink()
 lines=(folder/'in.dat').read_text().splitlines();lines[0]=str(case['budget']/30);lines[2]='0' if case['mode']=='transient' else '1';lines[4]='1' if case['receptors'] else '0'
 grid=(folder/'GRAL.geb').read_text().splitlines()
 if case['slices']==9:lines[9]='2 4 6 8 10 12 14 16 18';grid[5]='9'
 (folder/'in.dat').write_text('\n'.join(lines)+'\n');(folder/'GRAL.geb').write_text('\n'.join(grid)+'\n')
 (folder/'Max_Proc.txt').write_text('1\n');(folder/'meteopgt.all').write_text('10,1,10\nwind_dir,wind_speed,stability,frequency\n'+'\n'.join(f'{d},{speed},{sc},1' for d,speed,sc in case['weather'])+'\n')
 (folder/'mettimeseries.dat').write_text('\n'.join(f'01.01.2022 {h:02d} {speed} {d} {sc}' for h,(d,speed,sc) in enumerate(case['weather']))+'\n')
 (folder/'emissions_timeseries.txt').write_text('date;hour;1;2\n'+'\n'.join(f'01.01.2022;{h:02d};{factor1};{factor2}' for h,(factor1,factor2) in enumerate([(1,1),(0,0),(.5,2)][:len(case['weather'])]))+'\n')
 if case['receptors']:(folder/'Receptor.dat').write_text('2\n1,90,90,2,Near\n2,130,90,2,Far\n')
 if case['odour']:(folder/'Pollutant.txt').write_text('odour\n')
 kinds=('point','portal','line','area') if case['kind']=='mixed' else (case['kind'],)
 declared={}
 for kind in kinds:
  rows=[]
  for i in range(case['sources_per_kind']):
   x=40+(i%8)*12;y=40+(i//8)*12;sg=1+(i%2)
   if case['kind']=='mixed':sg=1+((('point','portal','line','area').index(kind)+i)%2)
   er=1
   if kind=='point':row=[x,y,2,er,0,0,0,1,1,293,sg]
   elif kind=='portal':row=[x,y,x+6,y,1,3,er,0,0,0,sg]
   elif kind=='line':row=[i+1,0,sg,x,y,1,x+10,y+4,2,2,-2,0,0,1000/math.sqrt(117),0,0,0,0,0]
   else:row=[x,y,2,8,8,2,er,0,0,0,sg]
   if case['deposition']:row += [100,100,30,0,.02,.02,.02,1]
   rows.append(','.join(map(str,row)))
  file={'point':'point.dat','portal':'portals.dat','line':'line.dat','area':'cadastre.dat'}[kind]
  headers=5 if kind=='line' else 1 if kind=='area' else 2
  (folder/file).write_text('\n'.join(['header']*headers+rows)+'\n')
  declared[kind]=len(rows)
 case=dict(case,domain_m=[0,200,0,200],resolution_m=20,situation_duration_s=30,workers=1,source_counts=declared,fixed_seed=True)
 save(folder/'synthetic_case.json',case)
 save(folder/'input_manifest.json',{p.name:dict(size=p.stat().st_size,sha256=sha(p)) for p in sorted(folder.iterdir()) if p.is_file() and p.name!='input_manifest.json'})
 return case
def outputs(folder,case):
 payload={};fields=0;values_count=0;nonzero=0;counts={'concentration':0,'deposition':0,'odour':0,'checkpoints':0,'receptors':0}
 for path in sorted(folder.glob('*.grz')):
  with zipfile.ZipFile(path) as z:
   for name in sorted(z.namelist()):
    raw=z.read(name);payload[path.name+':'+name]=hashlib.sha256(raw).hexdigest()
    kind=next((kind for ending,kind in [('.con','concentration'),('.dep','deposition'),('.odr','odour')] if name.endswith(ending)),None)
    if kind is None:continue
    h,x,y,dx,dy,nx,ny=struct.unpack_from('<iiiffii',raw)
    if (h,x,y,nx,ny)!=(-3,0,0,10,10) or dx!=20 or dy!=20:raise AssertionError('Unexpected grid header '+name)
    n=nx*ny*(4 if kind=='odour' else 1)
    if len(raw)!=28+n*4:raise AssertionError('Float payload format '+name)
    values=struct.unpack_from('<'+str(n)+'f',raw,28)
    if not all(math.isfinite(v) and v>=0 for v in values):raise AssertionError('Finite nonnegative output '+name)
    counts[kind]+=1;values_count+=n;nonzero+=sum(v>0 for v in values)
    if kind=='concentration':fields+=1
 for path in sorted(folder.glob('Transient_Concentrations*.tmp')):
  with zipfile.ZipFile(path) as z:
   for name in sorted(z.namelist()):payload[path.name+':'+name]=hashlib.sha256(z.read(name)).hexdigest();counts['checkpoints']+=1
 for name in ('ReceptorConcentrations.dat','Receptor_Timeseries_Transient.txt'):
  path=folder/name
  if path.exists():payload[name]=sha(path);counts['receptors']+=1
 expected=case['slices']*2*len(case['weather'])
 if fields!=expected:raise AssertionError(f'Concentration count {fields} != {expected}')
 if case['mode']=='transient' and counts['checkpoints']!=1:raise AssertionError('Residual checkpoint missing')
 if case['receptors'] and not counts['receptors']:raise AssertionError('Receptor missing')
 if case['deposition'] and not counts['deposition']:raise AssertionError('Deposition missing')
 if case['odour'] and not counts['odour']:raise AssertionError('Odour missing')
 if nonzero==0:raise AssertionError('All configured outputs are zero')
 return payload,counts,values_count
def inspect(package):
 manifest=json.loads((package/'qa/source_manifest.json').read_text())
 for variant in VARIANTS:
  actual={p.relative_to(package/'source'/variant).as_posix():sha(p) for p in sorted((package/'source'/variant/'src').iterdir()) if p.is_file()}
  if actual!=manifest['source_files'][variant]:raise AssertionError('Source manifest differs '+variant)
 a=manifest['source_files'][VARIANTS[0]];b=manifest['source_files'][VARIANTS[1]]
 if [name for name in a if a[name]!=b[name]]!=['src/Anfangko.cs']:raise AssertionError('Patch scope differs')
 old=(package/'source'/VARIANTS[0]/'src/Anfangko.cs').read_text();new=(package/'source'/VARIANTS[1]/'src/Anfangko.cs').read_text()
 if old[old.index('        public static float DeterministicRng'): ]!=new[new.index('        public static float DeterministicRng'): ]:raise AssertionError('RNG body differs')
 if re.findall(r'DeterministicRng\(ref m_z, ref m_w\)',old)!=re.findall(r'DeterministicRng\(ref m_z, ref m_w\)',new):raise AssertionError('RNG calls differ')
 return manifest
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--package-root',type=Path,default=Path(__file__).resolve().parents[1]);parser.add_argument('--run-dir',type=Path,required=True);parser.add_argument('--dotnet',required=True);parser.add_argument('--template',type=Path,default=Path(__file__).resolve().parents[1]/'inputs/template');args=parser.parse_args()
 package=args.package_root.resolve();run=args.run_dir.resolve()
 if run.exists():raise FileExistsError('Use a fresh isolated run directory')
 manifest=inspect(package);run.mkdir(parents=True)
 for name in ('logs','tmp','cache','qa','source','inputs','virtual_runs'):(run/name).mkdir()
 env=os.environ.copy();env.update(DOTNET_CLI_HOME=str(run/'cache/dotnet'),NUGET_PACKAGES=str(run/'cache/nuget'),TEMP=str(run/'tmp'),TMP=str(run/'tmp'),DOTNET_CLI_UI_LANGUAGE='en',DOTNET_NOLOGO='1')
 dotnet=str(Path(args.dotnet).resolve());started=time.perf_counter();builds={}
 def limit(seconds):
  remaining=900-(time.perf_counter()-started)
  if remaining<=0:raise TimeoutError('15-minute suite limit')
  return min(seconds,remaining)
 def build(project,label):
  code,out,err=process([dotnet,'build',str(project),'-c','Release','-t:Rebuild','-v:minimal','--nologo','/p:TreatWarningsAsErrors=true'],project.parent,env,limit(180));log=out+err;(run/'logs'/f'{label}_build.log').write_text(log)
  warning=re.search(r'(\d+) Warning\(s\)',log);error=re.search(r'(\d+) Error\(s\)',log)
  if code or not warning or not error or int(warning.group(1)) or int(error.group(1)):raise RuntimeError('Strict build failed '+label+'\n'+log)
  builds[label]={'warnings':0,'errors':0};print('[BUILD] '+label+' 0 0',flush=True)
 dlls={}
 for variant in VARIANTS:
  target=run/'source'/variant;shutil.copytree(package/'source'/variant,target,ignore=shutil.ignore_patterns('bin','obj'))
  build(target/'src/GRAL.csproj',variant);dlls[variant]=target/'src/bin/Release/net10.0/GRAL.dll'
 fixture=run/'selection_fixture';shutil.copytree(package/'tests',fixture,ignore=shutil.ignore_patterns('bin','obj'));build(fixture/'SelectionFixture.csproj','selection_fixture')
 fixturejson=run/'qa/selection_fixture.json';code,out,err=process([dotnet,str(fixture/'bin/Release/net10.0/SelectionFixture.dll'),str(dlls[VARIANTS[0]]),str(dlls[VARIANTS[1]]),str(fixturejson)],fixture,env,limit(180));(run/'logs/fixture.log').write_text(out+err)
 if code:raise RuntimeError('Actual DLL fixture failed\n'+out+err)
 print(out.strip(),flush=True);helper=json.loads(fixturejson.read_text())
 csvwrite(run/'qa/lookup_operation_counts.csv',helper['operation_counts'])
 benchmark=[{k:v for k,v in row.items() if not isinstance(v,list)} for row in helper['lookup_benchmark']];csvwrite(run/'qa/lookup_benchmark.csv',benchmark)
 records=[];data={};conditions=[]
 for rawcase in cases():
  template=run/'inputs'/rawcase['id'];case=configure(args.template,template,rawcase);conditions.append(case)
  for variant in VARIANTS:
   for repeat in (1,2):
    rid=case['id']+'_'+variant+'_r'+str(repeat);folder=run/'virtual_runs'/rid;shutil.copytree(template,folder)
    before=time.perf_counter();code,out,err=process([dotnet,str(dlls[variant]),str(folder)],folder,env,limit(60));(folder/'console.log').write_text(out);(folder/'stderr.log').write_text(err)
    core=folder/'Logfile_GRALCore.txt';problem=folder/'Problemreport_GRAL.txt'
    if code or not core.exists() or 'GRAL simulations finished at:' not in core.read_text(encoding='utf-8-sig') or (problem.exists() and problem.read_text(encoding='utf-8-sig').strip()):raise AssertionError('Actual Main completion '+rid+'\n'+out+err)
    allocations=list(map(int,re.findall(r'Using a total of (\d+) particles',out)))
    if len(allocations)!=1 or not 100<=allocations[0]<=3000:raise AssertionError('Actual allocation outside 100..3000 '+rid+repr(allocations))
    weather=[(float(s),int(d),int(sc)) for s,d,sc in re.findall(r'Init meteo:\s+wind speed \[m/s\]: ([0-9.]+)\s+direction \[deg\]: ([0-9]+)\s+Stability class \[-\]: ([0-9]+)',out)]
    expected=[(s,d*10,sc) for d,s,sc in case['weather']]
    if weather!=expected:raise AssertionError('Actual weather differs '+repr(weather)+' != '+repr(expected))
    fresh_mass=None
    if case['mode']=='transient':
     if 'Reading emissions_timeseries.txt successful' not in out:raise AssertionError('Emission schedule not read '+rid)
     reported=re.findall(r'Summarized emission rates per source group in kg\s*\n[^\n]*SG:[^\n]*\n([^\n]+)',out)
     if not reported:raise AssertionError('Fresh emission diagnostic missing')
     fresh_mass=list(map(float,reported[-1].split()))
     expected_mass=[4*(1+0+.5)*30/3600,4*(1+0+2)*30/3600]
     if len(fresh_mass)!=2 or not all(math.isclose(a,b,rel_tol=.005) for a,b in zip(fresh_mass,expected_mass)):raise AssertionError('Fresh emission schedule mismatch '+repr(fresh_mass))
    sourcepatterns={'point':'point sources','portal':'tunnel portals','line':'line source segments','area':'area source partitions'}
    sourcecounts={}
    for kind,description in sourcepatterns.items():
     found=re.findall(r'Total number of '+description+r': (\d+)',out)
     sourcecounts[kind]=int(found[0]) if found else 0
     declared=case['source_counts'].get(kind,0)
     if (sourcecounts[kind]<declared if case['deposition'] else sourcecounts[kind]!=declared):raise AssertionError('Actual source type/count mismatch '+kind+' '+rid)
    
    payload,counts,nvalues=outputs(folder,case)
    checknames=('exit_zero','completion_marker','empty_problem_report','particle_budget_100_to_3000','source_types_declared','actual_meteorology','dynamic_grid_200m_20m','finite_nonnegative_float_payloads','expected_concentration_count','expected_auxiliary_outputs','nonzero_output','main_within_60s')
    record=dict(run_id=rid,case=case['id'],variant=variant,repeat=repeat,elapsed_s=time.perf_counter()-before,actual_particles=allocations[0],actual_weather=weather,source_counts_declared=case['source_counts'],actual_source_counts=sourcecounts,counts=counts,float_values_checked=nvalues,payload_sha256=payload,fresh_mass_kg=fresh_mass,checks={k:True for k in checknames},checks_passed=len(checknames))
    if case['mode']=='transient':record['checks']['emission_schedule_read_and_cumulative_fresh_mass']=True;record['checks_passed']+=1
    records.append(record);data[(case['id'],variant,repeat)]=record;print(f"[MAIN] {len(records)}/{len(cases())*4} {rid}",flush=True)
 comparisons=[];repeats=[]
 for case in conditions:
  for variant in VARIANTS:
   a=data[(case['id'],variant,1)];b=data[(case['id'],variant,2)]
   if a['payload_sha256']!=b['payload_sha256']:raise AssertionError('Fixed-seed repeat differs '+case['id']+' '+variant)
   repeats.append(dict(case=case['id'],variant=variant,payloads_equal=True,payloads=len(a['payload_sha256'])))
  for repeat in (1,2):
   a=data[(case['id'],VARIANTS[0],repeat)];b=data[(case['id'],VARIANTS[1],repeat)]
   if a['payload_sha256']!=b['payload_sha256'] or a['actual_particles']!=b['actual_particles']:raise AssertionError('Baseline/candidate differs '+case['id'])
   comparisons.append(dict(case=case['id'],repeat=repeat,actual_particles=a['actual_particles'],payloads=len(a['payload_sha256']),payloads_equal=True,changed_payloads=0,max_absolute_concentration_difference=0,relative_l1=0))
 inspect(package)
 for variant in VARIANTS:
  actual={p.relative_to(run/'source'/variant).as_posix():sha(p) for p in sorted((run/'source'/variant/'src').iterdir()) if p.is_file()}
  if actual!=manifest['source_files'][variant]:raise AssertionError('Compiled copy differs '+variant)
 summary=dict(status='pass',source_files_per_variant=len(manifest['source_files'][VARIANTS[0]]),strict_builds=builds,conditions=len(conditions),main_runs=len(records),main_checks_passed=sum(x['checks_passed'] for x in records),single_worker_repeat_pairs=len(repeats),baseline_candidate_pairs=len(comparisons),compared_payload_pairs=sum(x['payloads'] for x in comparisons),concentration_payloads=sum(x['counts']['concentration'] for x in records),checkpoint_payloads=sum(x['counts']['checkpoints'] for x in records),emission_schedule_verified_runs=sum(x['fresh_mass_kg'] is not None for x in records),float_values_checked=sum(x['float_values_checked'] for x in records),helper_checks_passed=helper['checks_passed'],helper_searches=helper['helper_searches'],particle_state_pairs=helper['particle_state_pairs'],particle_state_arrays_per_pair=helper['particle_state_arrays_per_pair'],elapsed_s=time.perf_counter()-started,conditions_detail=conditions,comparisons=comparisons,repeat_results=repeats,runs=records,limits=['Fixed-seed bytewise equality is required for controlled one-worker Main cases only.','Unfixed TickCount seeds can change when execution timing changes.','Two-worker equality is covered only by the independent start-coordinate component fixture.','The lookup benchmark includes prefix construction but excludes dispersion, full initialization, meteorology and I/O.','No end-to-end or production-domain speedup claim.','Thirty seconds per synthetic weather situation, not one hour despite hourly labels.','Emission rates vary between transient situations; the existing allocator does not reassign source particle counts each situation.','Valid source count arrays are nonnegative; invalid negative count input is outside this patch.'])
 save(run/'qa/validation_summary.json',summary);csvwrite(run/'qa/output_comparison.csv',comparisons)
 print(f"[PASS] {len(records)} Main; {summary['main_checks_passed']} Main checks; {helper['checks_passed']} actual DLL checks",flush=True)
if __name__=='__main__':main()
