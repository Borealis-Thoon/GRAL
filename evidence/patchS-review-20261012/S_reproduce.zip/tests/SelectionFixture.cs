using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading.Tasks;

class SelectionFixture
{
    const BindingFlags Fields = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;
    static int checks;
    static void Assert(bool condition, string message) { if (!condition) throw new Exception(message); checks++; }
    static int Scan(int[] counts, int count, double offset, int particle)
    {
        double sum = offset;
        for (int j = 1; j <= count; j++) { sum += counts[j]; if (particle <= sum) return j; }
        return 0;
    }
    static void Set(Type program, string name, object value)
    {
        var field = program.GetField(name, Fields);
        field.SetValue(null, Convert.ChangeType(value, field.FieldType));
    }
    static void SetArray(Type program, string name, int index, object value)
    {
        var array = (Array)program.GetField(name, Fields).GetValue(null);
        array.SetValue(Convert.ChangeType(value, array.GetType().GetElementType()), index);
    }
    static Dictionary<string, string> Calculate(Type program, Type start, int[][] counts, int workers, int situation)
    {
        string[] kinds = { "PS", "TS", "LS", "AS" };
        int total = counts.Sum(x => x.Skip(1).Sum());
        Set(program, "NTEILMAX", total); Set(program, "GridVolume", 800d); Set(program, "TAUS", 30d);
        Set(program, "ISTATIONAER", 1); Set(program, "Topo", 0); Set(program, "BuildingsExist", false);
        Set(program, "XsiMinGral", 0d); Set(program, "EtaMinGral", 0d); Set(program, "XsiMaxGral", 200d); Set(program, "EtaMaxGral", 200d);
        Set(program, "IKOOAGRAL", 0d); Set(program, "JKOOAGRAL", 0d); Set(program, "UseFixedRndSeedVal", true);
        ((ParallelOptions)program.GetField("pOptions", Fields).GetValue(null)).MaxDegreeOfParallelism = workers;
        program.GetField("SourceGroups", Fields).SetValue(null, new List<int> { 1, 2 });
        foreach (string kind in kinds)
        {
            int k = Array.IndexOf(kinds, kind), count = counts[k].Length - 1;
            Set(program, kind + "_Count", count); Set(program, kind + "_PartSum", counts[k].Skip(1).Sum());
            foreach (var field in program.GetFields(Fields).Where(f => f.Name.StartsWith(kind + "_") && f.FieldType.IsArray && f.FieldType.GetArrayRank() == 1))
                field.SetValue(null, Array.CreateInstance(field.FieldType.GetElementType(), count + 1));
            program.GetField(kind + "_PartNumb", Fields).SetValue(null, counts[k]);
            for (int i = 1; i <= count; i++)
            {
                SetArray(program, kind + "_ER", i, .25 * i * situation); SetArray(program, kind + "_ER_Dep", i, .3 * i);
                SetArray(program, kind + "_SG", i, i % 2 + 1); SetArray(program, kind + "_Mode", i, i % 3);
                SetArray(program, kind + "_V_sed", i, .02); SetArray(program, kind + "_V_Dep", i, .03);
                if (kind == "PS") { SetArray(program, "PS_X", i, 40 + i * .1); SetArray(program, "PS_Y", i, 50 + i * .1); SetArray(program, "PS_D", i, 1); SetArray(program, "PS_effqu", i, 2); SetArray(program, "PS_HorExitVel", i, i % 2 == 0 ? .2 : 0); }
                if (kind == "LS" || kind == "TS")
                {
                    SetArray(program, kind + "_X1", i, 50 + i * .1); SetArray(program, kind + "_X2", i, 60 + i * .1);
                    SetArray(program, kind + "_Y1", i, 60 + i * .1); SetArray(program, kind + "_Y2", i, 60 + i * .1);
                    SetArray(program, kind + "_Z1", i, 2); SetArray(program, kind + "_Z2", i, 4);
                    if (kind == "LS") { SetArray(program, "LS_Width", i, 2); SetArray(program, "LS_Laerm", i, i % 3 - 1); if (i % 4 == 0) SetArray(program, "LS_X2", i, 50 + i * .1); }
                }
                if (kind == "AS") { SetArray(program, "AS_X", i, 70 + i * .1); SetArray(program, "AS_Y", i, 80 + i * .1); SetArray(program, "AS_Z", i, 2); SetArray(program, "AS_dX", i, 8); SetArray(program, "AS_dY", i, 8); SetArray(program, "AS_dZ", i, 2); }
            }
        }
        string[] arrays = { "ParticleSource", "ParticleSG", "SourceType", "ParticleMode", "Xcoord", "YCoord", "ZCoord", "ParticleMass", "ParticleVdep", "ParticleVsed" };
        foreach (string name in arrays) { var field = program.GetField(name, Fields); field.SetValue(null, Array.CreateInstance(field.FieldType.GetElementType(), total + 1)); }
        start.GetMethod("Calculate", Fields).Invoke(null, null);
        var result = new Dictionary<string, string>();
        foreach (string name in arrays) { var array = (Array)program.GetField(name, Fields).GetValue(null); byte[] raw = new byte[Buffer.ByteLength(array)]; Buffer.BlockCopy(array, 0, raw, 0, raw.Length); result[name] = Convert.ToHexString(SHA256.HashData(raw)); }
        return result;
    }
    static void Main(string[] args)
    {
        var candidateAssembly = new AssemblyLoadContext("candidate", false).LoadFromAssemblyPath(Path.GetFullPath(args[1]));
        var baselineAssembly = new AssemblyLoadContext("baseline", false).LoadFromAssemblyPath(Path.GetFullPath(args[0]));
        var start = candidateAssembly.GetType("GRAL_2001.StartCoordinates");
        var build = start.GetMethod("CumulativeParticles", Fields).CreateDelegate<Func<int[], int, double, double[]>>();
        var find = start.GetMethod("FindSource", Fields).CreateDelegate<Func<double[], int, int>>();
        var random = new Random(20261012);
        var cases = new List<int[]> { new[] { 0 }, new[] { 0, 0 }, new[] { 0, 1 }, new[] { 0, 0, 0, 3, 0, 2, 0 }, new[] { 0, 2, 0, 0, 3 }, new[] { 0, int.MaxValue } };
        for (int c = 0; c < 250; c++) { int count = random.Next(1, 300); cases.Add(new[] { 0 }.Concat(Enumerable.Range(1, count).Select(_ => random.Next(0, 21))).ToArray()); }
        int helperStart = checks, searches = 0;
        foreach (var counts in cases)
            foreach (int offset in new[] { 0, 1, 71, 1000, -1000, int.MinValue + 23 })
            {
                var cumulative = build(counts, counts.Length - 1, offset); double sum = offset;
                Assert(cumulative[0] == offset, "Offset changed");
                for (int i = 1; i < counts.Length; i++) { sum += counts[i]; Assert(cumulative[i] == sum, "Cumulative addition differs"); }
                var queries = new HashSet<int> { 0, 1, offset, Math.Max(0, offset - 1), offset + 1, int.MaxValue };
                foreach (double boundary in cumulative) { if (boundary >= 0 && boundary <= int.MaxValue) queries.Add((int)boundary); if (boundary >= 1 && boundary <= int.MaxValue) queries.Add((int)boundary - 1); if (boundary >= 0 && boundary < int.MaxValue) queries.Add((int)boundary + 1); }
                for (int i = 0; i < 250; i++) queries.Add(random.Next(offset, (int)Math.Min(int.MaxValue, sum + 3)));
                foreach (int query in queries) { Assert(find(cumulative, query) == Scan(counts, counts.Length - 1, offset, query), "First-match selection differs"); searches++; }
            }
        int helperChecks = checks - helperStart;
        var stateCases = new List<int[][]>();
        for (int kind = 0; kind < 4; kind++) { var c = Enumerable.Range(0, 4).Select(_ => new[] { 0 }).ToArray(); c[kind] = new[] { 0, 20, 31, 17, 32 }; stateCases.Add(c); }
        stateCases.Add(new[] { new[] { 0, 20, 0, 31 }, new[] { 0, 16, 0, 20 }, new[] { 0, 17, 32 }, new[] { 0, 0, 6, 12 } });
        stateCases.Add(Enumerable.Range(0, 4).Select(k => new[] { 0 }.Concat(Enumerable.Range(1, 32).Select(i => 20 + i + k)).ToArray()).ToArray());
        var stateRecords = new List<object>();
        foreach (int workers in new[] { 1, 2 })
            for (int c = 0; c < stateCases.Count; c++)
                foreach (int situation in new[] { 1, 2 })
                {
                    var a = Calculate(baselineAssembly.GetType("GRAL_2001.Program"), baselineAssembly.GetType("GRAL_2001.StartCoordinates"), stateCases[c], workers, situation);
                    var b = Calculate(candidateAssembly.GetType("GRAL_2001.Program"), start, stateCases[c], workers, situation);
                    foreach (string key in a.Keys) Assert(a[key] == b[key], "Particle-state differs: " + key);
                    stateRecords.Add(new { case_index = c, workers, situation, particles = stateCases[c].Sum(x => x.Skip(1).Sum()), equal_arrays = a.Count, baseline = a, candidate = b });
                }
        var cost = new List<object>(); var benchmark = new List<object>(); long sink = 0;
        foreach (int count in new[] { 16, 256, 4096 })
        {
            var counts = new[] { 0 }.Concat(Enumerable.Repeat(20, count)).ToArray();
            var cumulative = build(counts, count, 0);
            foreach (int queries in new[] { 1000, 3000 })
            {
                int[] ids = Enumerable.Range(0, queries).Select(q => 1 + (int)((long)q * count * 20 / queries)).ToArray();
                long linearComparisons = 0, binaryComparisons = 0;
                foreach (int id in ids) { linearComparisons += Scan(counts, count, 0, id); int low = 1, high = count, comparisons = 1; while (low < high) { int middle = low + (high - low) / 2; comparisons++; if (cumulative[middle] >= id) high = middle; else low = middle + 1; } binaryComparisons += comparisons; Assert(find(cumulative, id) == Scan(counts, count, 0, id), "Benchmark oracle differs"); }
                cost.Add(new { sources = count, queries, prefix_additions = count, linear_comparisons = linearComparisons, binary_comparisons = binaryComparisons, comparison_reduction_percent = 100d * (1d - (double)binaryComparisons / linearComparisons) });
                for (int warm = 0; warm < 20; warm++) foreach (int id in ids) { sink += Scan(counts, count, 0, id); sink += find(cumulative, id); }
                var oldTimes = new List<double>(); var newTimes = new List<double>();
                const int batches = 40;
                for (int round = 0; round < 7; round++)
                {
                    Action old = () => { for (int batch = 0; batch < batches; batch++) foreach (int id in ids) sink += Scan(counts, count, 0, id); };
                    Action next = () => { for (int batch = 0; batch < batches; batch++) { var prefix = build(counts, count, 0); foreach (int id in ids) sink += find(prefix, id); } };
                    var watch = Stopwatch.StartNew(); if (round % 2 == 0) old(); else next(); watch.Stop(); if (round % 2 == 0) oldTimes.Add(watch.Elapsed.TotalMilliseconds / batches); else newTimes.Add(watch.Elapsed.TotalMilliseconds / batches);
                    watch.Restart(); if (round % 2 == 0) next(); else old(); watch.Stop(); if (round % 2 == 0) newTimes.Add(watch.Elapsed.TotalMilliseconds / batches); else oldTimes.Add(watch.Elapsed.TotalMilliseconds / batches);
                }
                oldTimes.Sort(); newTimes.Sort();
                benchmark.Add(new { sources = count, queries, rounds = 7, batches_per_round = batches, candidate_includes_prefix_construction = true, old_median_ms_per_batch = oldTimes[3], new_median_ms_per_batch = newTimes[3], ratio_old_over_new = oldTimes[3] / newTimes[3], baseline_samples_ms = oldTimes, candidate_samples_ms = newTimes });
            }
        }
        File.WriteAllText(args[2], JsonSerializer.Serialize(new { status = "pass", checks_passed = checks, helper_checks = helperChecks, helper_searches = searches, helper_count_vectors = cases.Count, helper_offsets = 6, state_cases = stateRecords, particle_state_pairs = stateRecords.Count, particle_state_arrays_per_pair = 10, operation_counts = cost, lookup_benchmark = benchmark, checksum_sink = sink }, new JsonSerializerOptions { WriteIndented = true }));
        Console.WriteLine("[PASS] " + checks + " checks; " + searches + " searches; " + stateRecords.Count + " particle-state pairs");
    }
}
