"""Replay draft residual-policy review in isolated copies; no remote operations."""
from pathlib import Path
import argparse,hashlib,json,math,os,re,shutil,struct,subprocess,sys,time,zipfile,difflib

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def process(command,cwd,env,timeout=60):
    p=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    try:out,err=p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name=='nt':subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        else:p.kill()
        p.communicate(timeout=10);raise TimeoutError('Owned process timed out')
    return p.returncode,out.decode('utf-8',errors='replace'),err.decode('utf-8',errors='replace')
def clean_copy(source,target):shutil.copytree(source,target,ignore=shutil.ignore_patterns('bin','obj','.git'))
def fields(folder):
    records=[]
    for p in sorted(folder.glob('*.grz')):
        with zipfile.ZipFile(p) as z:
            for n in sorted(z.namelist()):
                if not n.endswith('.con'):continue
                raw=z.read(n);header,x,y,dx,dy,nx,ny=struct.unpack_from('<iiiffii',raw)
                assert header==-3 and nx==ny==10 and len(raw)==28+nx*ny*4
                v=struct.unpack_from('<100f',raw,28);assert all(math.isfinite(x) and x>=0 for x in v)
                m=re.fullmatch(r'(\d{5})-1(\d{2})\.con',n);assert m
                records.append({'situation':int(m[1]),'sg':int(m[2]),'sha256':hashlib.sha256(raw).hexdigest(),'sum':math.fsum(v),'values':list(v)})
    return records

def witness(source):
    p=source/'src/TeilchenAufteilung.cs';txt=p.read_text(encoding='utf-8-sig');a=txt.index('public static void SetResidualParticleMass()');b=txt.index('{',a);depth=1;c=b+1
    while depth:
        if txt[c]=='{':depth+=1
        elif txt[c]=='}':depth-=1
        c+=1
    loc=c-1;txt=txt[:loc]+'    Console.WriteLine("REF_WITNESS " + Program.IWET + " " + ParticleMassActive.ToString("R", System.Globalization.CultureInfo.InvariantCulture));\n        '+txt[loc:];p.write_text(txt,encoding='utf-8')
    return 'Only a Console.WriteLine at the end of SetResidualParticleMass; production source remains unchanged.'

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--old-source-root',type=Path,required=True);ap.add_argument('--new-source-root',type=Path,required=True);ap.add_argument('--inputs-root',type=Path,required=True);ap.add_argument('--run-dir',type=Path,required=True);ap.add_argument('--dotnet',default='dotnet');args=ap.parse_args();run=args.run_dir.resolve()
    if run.exists():raise FileExistsError(run)
    run.mkdir(parents=True);start=time.perf_counter();env=os.environ.copy();env.update({'DOTNET_CLI_HOME':str(run/'cache/dotnet_home'),'NUGET_PACKAGES':str(run/'cache/nuget'),'TMP':str(run/'tmp'),'TEMP':str(run/'tmp'),'DOTNET_NOLOGO':'1','DOTNET_CLI_UI_LANGUAGE':'en'})
    for n in ('logs','qa','tmp'): (run/n).mkdir()
    builds={};copies={};source_manifest={}
    def build(project,label):
        code,out,err=process([args.dotnet,'build',str(project),'-c','Release','-t:Rebuild','-v:minimal','--nologo','/p:TreatWarningsAsErrors=true'],project.parent,env,180);log=out+err;(run/'logs'/f'{label}_build.log').write_text(log,encoding='utf-8');warn=re.search(r'(\d+) Warning\(s\)',log);errors=re.search(r'(\d+) Error\(s\)',log)
        assert code==0 and warn and errors and int(warn[1])==0 and int(errors[1])==0,(label,log[-2500:]);builds[label]={'exit_code':code,'warnings':0,'errors':0};print('[BUILD] '+label+' 0 0',flush=True)
    for generation,source_root in [('old',args.old_source_root),('new',args.new_source_root)]:
        for policy in ('C2_active_reference','C3_adaptive_budget'):
            name=generation+'_'+policy;source=source_root/policy;target=run/'sources'/name;clean_copy(source,target);copies[name]=target;source_manifest[name]={p.relative_to(source).as_posix():sha(p) for p in sorted(source.rglob('*')) if p.is_file() and 'bin' not in p.parts and 'obj' not in p.parts and '.git' not in p.parts};build(target/'src/GRAL.csproj',name)
    save(run/'qa/source_manifest.json',source_manifest)
    fixture=run/'fixture';fixture.mkdir();script=Path(__file__).parent
    for n in ('Checks.cs','DraftChecks.csproj'):shutil.copy2(script/n,fixture/n)
    build(fixture/'DraftChecks.csproj','actual_dll_fixture')
    for policy in ('C2_active_reference','C3_adaptive_budget'):
        code,out,err=process([args.dotnet,str(fixture/'bin/Release/net10.0/DraftChecks.dll'),str(copies['new_'+policy]/'src/bin/Release/net10.0/GRAL.dll'),str(run/'qa'/f'{policy}_checks.json')],fixture,env);(run/'logs'/f'{policy}_checks.log').write_text(out+err,encoding='utf-8');assert code==0,(policy,out,err);print(out.strip(),flush=True)
    runtime_source=script/'runtime';runtime=run/'runtime_fixture';clean_copy(runtime_source,runtime)
    source=(copies['new_C3_adaptive_budget']/'src/Zeitschleife_nonsteadystate.cs').read_text(encoding='utf-8-sig');extracted=(runtime/'ExtractedCandidate.cs').read_text(encoding='utf-8-sig')
    stripped=extracted.replace('                    Program.EnterRow();\n','').replace('                    Program.ExitRow();\n','')
    def method(text,begin):
        a=text.index(begin);b=text.index('{',a);depth=1;c=b+1
        while depth:
            if text[c]=='{':depth+=1
            elif text[c]=='}':depth-=1
            c+=1
        return text[a:c]
    for begin in ('private static int ResidualSplitCount(','public static void PlanResidual()'): assert method(source,begin) in stripped
    pm=(copies['new_C3_adaptive_budget']/'src/TeilchenAufteilung.cs').read_text(encoding='utf-8-sig')
    for begin in ('public static void SetResidualParticleMass()','private static double ActiveEmission('):assert method(pm,begin) in stripped
    build(runtime/'KernelFixture.csproj','worker_cancel_fixture')
    code,out,err=process([args.dotnet,str(runtime/'bin/Release/net10.0/KernelFixture.dll'),str(run/'qa/runtime_checks.json')],runtime,env);(run/'logs/runtime_fixture_run.log').write_text(out+err,encoding='utf-8');assert code==0,(out,err)
    runtime_checks=json.loads((run/'qa/runtime_checks.json').read_text());assert runtime_checks['checks_passed']==11
    print('[PASS] runtime checks 11',flush=True)
    actual=[]
    def run_main(source,folder,rid,expected_situations,expect_load=False):
        code,out,err=process([args.dotnet,str(source/'src/bin/Release/net10.0/GRAL.dll'),str(folder)],folder,env);(folder/'console.log').write_text(out,encoding='utf-8');(folder/'stderr.log').write_text(err,encoding='utf-8');(run/'logs'/f'{rid}_console.log').write_text(out,encoding='utf-8');(run/'logs'/f'{rid}_stderr.log').write_text(err,encoding='utf-8');f=fields(folder);prob=folder/'Problemreport_GRAL.txt';core=folder/'Logfile_GRALCore.txt';refs=[{'situation':int(s),'reference':float(v)} for s,v in re.findall(r'REF_WITNESS (\d+) ([\d.eE+\-]+)',out)];weather=[int(x) for x in re.findall(r'Weather number: (\d+)',out)];checks={'exit_zero':code==0,'completion':core.exists() and 'GRAL simulations finished at:' in core.read_text(encoding='utf-8-sig'),'problem_empty':not prob.exists() or not prob.read_text(encoding='utf-8-sig').strip(),'float32_concentration_format':True,'finite_nonnegative':True,'expected_fields':[(x['situation'],x['sg']) for x in f]==[(s,g) for s in expected_situations for g in (1,2)],'alloff_has_carryover':sum(x['sum'] for x in f if x['situation']==3)>0 if 3 in expected_situations else True,'restart_checkpoint_loaded':'Reading Transient_Concentrations.tmp successful!' in out if expect_load else True}
        assert all(checks.values()),(rid,checks,out[-2000:],err);record={'run_id':rid,'checks':checks,'fields':f,'references':refs,'weather_numbers':weather};actual.append(record);print('[RUN] '+rid+' pass',flush=True);return record
    for n in (100,1000,3000):
        for repeat in (1,2):
            for name,source in copies.items():
                rid=f'n{n}_{name}_r{repeat}';folder=run/'main'/rid;clean_copy(args.inputs_root/f'budget{n}_fixed',folder);run_main(source,folder,rid,[1,2,3])
    repeat_matches=[];effect=[]
    for n in (100,1000,3000):
        for name in copies:
            first=next(x for x in actual if x['run_id']==f'n{n}_{name}_r1');second=next(x for x in actual if x['run_id']==f'n{n}_{name}_r2');ok=[x['sha256'] for x in first['fields']]==[x['sha256'] for x in second['fields']];assert ok;repeat_matches.append({'budget':n,'variant':name,'identical':ok})
        for policy in ('C2_active_reference','C3_adaptive_budget'):
            old=next(x for x in actual if x['run_id']==f'n{n}_old_{policy}_r1');new=next(x for x in actual if x['run_id']==f'n{n}_new_{policy}_r1')
            for situation in (1,2,3):
                of=[x for x in old['fields'] if x['situation']==situation];nf=[x for x in new['fields'] if x['situation']==situation];ov=[v for x in of for v in x['values']];nv=[v for x in nf for v in x['values']];diff=math.fsum(abs(a-b) for a,b in zip(ov,nv));den=math.fsum(abs(v) for v in ov);effect.append({'budget':n,'policy':policy,'situation':situation,'old_sum':math.fsum(ov),'new_sum':math.fsum(nv),'relative_l1_percent':100*diff/den if den else None,'payloads_identical':[x['sha256'] for x in of]==[x['sha256'] for x in nf]})
    # Probe actual checkpoint loading with a reference-only witness in a separate test copy.
    restart=[]
    for name,source in copies.items():
        target=run/'witness_sources'/name;clean_copy(source,target);witness_scope=witness(target);build(target/'src/GRAL.csproj',name+'_reference_witness')
        full=run/'restart'/name/'continuous';clean_copy(args.inputs_root/'budget1000_fixed',full);continuous=run_main(target,full,name+'_continuous',[1,2,3])
        split=run/'restart'/name/'prefix_resume';clean_copy(args.inputs_root/'budget1000_fixed',split);original_met=(split/'mettimeseries.dat').read_bytes();(split/'mettimeseries.dat').write_bytes(b'\n'.join(original_met.splitlines()[:2])+b'\n');prefix=run_main(target,split,name+'_prefix',[1,2]);checkpoint=next(split.glob('Transient_Concentrations*.tmp'));evidence=run/'qa/checkpoint_evidence'/name;evidence.mkdir(parents=True);stored=evidence/checkpoint.name;shutil.copy2(checkpoint,stored)
        with zipfile.ZipFile(stored) as archive:raw=archive.read(archive.namelist()[0])
        assert struct.unpack_from('<i',raw,48)[0]==2
        checkpoint_hash=hashlib.sha256(raw).hexdigest();(split/'mettimeseries.dat').write_bytes(original_met);(split/'KeepAndReadTransientTempFiles.dat').unlink();resume=run_main(target,split,name+'_resume',[1,2,3],True);assert 3 in resume['weather_numbers'] and 1 not in resume['weather_numbers'] and 2 not in resume['weather_numbers'];cr=next(x['reference'] for x in continuous['references'] if x['situation']==3);rr=next(x['reference'] for x in resume['references'] if x['situation']==3);fixed=name.startswith('new_');assert (cr==rr)==fixed,(name,cr,rr);restart.append({'variant':name,'continuous_all_off_reference':cr,'resume_all_off_reference':rr,'reference_equal':cr==rr,'prefix_checkpoint_sha256':checkpoint_hash,'prefix_checkpoint_zip_sha256':sha(stored),'prefix_checkpoint_evidence':stored.relative_to(run).as_posix(),'prefix_checkpoint_situation':2,'resume_weather_numbers':resume['weather_numbers'],'scope':witness_scope,'full_output_bitwise_required':False})
    components={n:json.loads((run/'qa'/f'{n}_checks.json').read_text()) for n in ('C2_active_reference','C3_adaptive_budget')};summary={'status':'pass','strict_builds':builds,'actual_main_runs':len(actual),'actual_main_checks':sum(len(x['checks']) for x in actual),'repeat_pairs':repeat_matches,'component_check_count':sum(x['checks_passed'] for x in components.values())+runtime_checks['checks_passed'],'worker_cancellation':runtime_checks,'components':components,'restart':restart,'effects':effect,'elapsed_s':time.perf_counter()-start,'limitations':['Main reference witness is in separate test copies only.','Restart equality is limited to reference mass; original engine state can change full output.','Actual field differences have no physical truth oracle.','All-off policy deliberately returns to existing nominal reference.','No remote changes.']}
    for record in actual:
        for f in record['fields']:f.pop('values')
    save(run/'qa/actual_main.json',actual);save(run/'qa/review_summary.json',summary);print('[PASS] '+str(len(actual))+' Main runs',flush=True)
if __name__=='__main__':main()
