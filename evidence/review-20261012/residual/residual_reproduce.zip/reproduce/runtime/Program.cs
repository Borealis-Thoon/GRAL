using System.Text.Json;
namespace GRAL_2001 {
static class Consts { public const byte DepoOnly = 2; }
static class Program {
 public static double TAUS=1,TPS=1,GridVolume=1000000000.0/3600;
 public static double ParticleMassMean=26;
 public static int IWET=1,NII=1,NJJ=1,NKK_Transient=1;
 public static float DXK=1,DYK=1,TransConcThreshold=0;
 public static float[] DZK_Trans=new float[]{0,1};
 public static List<int> SourceGroups=new(){0,1,2,3};
 public static float[,] EmFacTimeSeries=new float[3,4];
 public static bool EmissionTimeseriesExist=true;
 public static double[] PS_ER=new double[]{0,1},LS_ER=new double[]{0,2},TS_ER=new double[]{0,3},AS_ER=new double[]{0,20};
 public static float[] PS_ER_Dep=new float[]{0,1},LS_ER_Dep=new float[]{0,1},TS_ER_Dep=new float[]{0,1},AS_ER_Dep=new float[]{0,1};
 public static byte[] PS_Mode=new byte[]{0,0},LS_Mode=new byte[]{0,0},TS_Mode=new byte[]{0,0},AS_Mode=new byte[]{0,0};
 public static byte[] PS_SG=new byte[]{0,0},LS_SG=new byte[]{0,1},TS_SG=new byte[]{0,2},AS_SG=new byte[]{0,3};
 public static int PS_Count=1,LS_Count=1,TS_Count=1,AS_Count=1;
 public static float[][][][] Conz4d;
 public static System.Threading.CancellationTokenSource CancelToken = new();
 public static System.Threading.Tasks.ParallelOptions pOptions = new() { MaxDegreeOfParallelism = 1 };
 static int checks=0;
 static int activeRows=0,maxRows=0,visitedRows=0,cancelAfterRows=0;
 public static void EnterRow() { int active=System.Threading.Interlocked.Increment(ref activeRows);maxRows=Math.Max(maxRows,active);int visited=System.Threading.Interlocked.Increment(ref visitedRows);if(cancelAfterRows>0 && visited>=cancelAfterRows) CancelToken.Cancel();System.Threading.Thread.Sleep(1); }
 public static void ExitRow() { System.Threading.Interlocked.Decrement(ref activeRows); }
 static void Check(bool ok,string name) { checks++; if(!ok) throw new Exception(name); }
 static int Old(double m,double mass) { int r=(int)(m/mass); return r/10+1; }
 static int C1(double m,double mass) => (int)Math.Min(100000,
                Math.Floor(Math.Floor(m / mass) / 10) + 1);
 static void Factors(float a,float b,float c,float d) { EmFacTimeSeries[0,0]=a;EmFacTimeSeries[0,1]=b;EmFacTimeSeries[0,2]=c;EmFacTimeSeries[0,3]=d; }
 static void Grid(float[] masses,double budget) {
  NII=masses.Length;NJJ=1;NKK_Transient=1;SourceGroups=new(){0};TAUS=1;TPS=budget;GridVolume=1;ParticleManagement.ParticleMassActive=1;TransConcThreshold=0;
  Conz4d=new float[NII+1][][][];
  for(int i=1;i<=NII;i++) { Conz4d[i]=new float[2][][];Conz4d[i][1]=new float[2][];Conz4d[i][1][1]=new float[]{masses[i-1]}; }
 }
 static object Budget(float[] masses,double budget) {
  Grid(masses,budget);ZeitschleifeNonSteadyState.ResetK();int before=masses.Sum(x=>ZeitschleifeNonSteadyState.Count(x));
  ZeitschleifeNonSteadyState.PlanResidual();int after=masses.Sum(x=>ZeitschleifeNonSteadyState.Count(x));
  return new {entries=masses.Length,budget,initial_count=before,final_count=after,final_k=ZeitschleifeNonSteadyState.K,meets_target=after<=budget};
 }
 static void Main(string[] args) {
  var results=new Dictionary<string,object>();
  Grid(Enumerable.Repeat(100f,16).ToArray(),32);cancelAfterRows=0;visitedRows=0;maxRows=0;
  ZeitschleifeNonSteadyState.PlanResidual();
  Check(pOptions.MaxDegreeOfParallelism==1,"configured worker option");Check(maxRows==1,"one active worker row");Check(visitedRows==32,"two passes visit every row");Check(ZeitschleifeNonSteadyState.K==55,"normal planning unchanged");
  results["one_worker"]=new {configured_max_degree=pOptions.MaxDegreeOfParallelism,max_concurrent_rows=maxRows,visited_rows=visitedRows,final_k=ZeitschleifeNonSteadyState.K};
  CancelToken.Cancel();Conz4d=null;NII=1000000;visitedRows=0;var timer=System.Diagnostics.Stopwatch.StartNew();ZeitschleifeNonSteadyState.PlanResidual();timer.Stop();
  Check(visitedRows==0,"already cancelled reads no grid row");Check(timer.Elapsed.TotalSeconds<1,"already cancelled returns within one second");
  results["already_cancelled"]=new {visited_rows=visitedRows,elapsed_s=timer.Elapsed.TotalSeconds,no_grid_index_read=true};
  CancelToken.Dispose();CancelToken=new();Grid(Enumerable.Repeat(100f,1000).ToArray(),1);visitedRows=0;maxRows=0;cancelAfterRows=3;
  timer.Restart();ZeitschleifeNonSteadyState.PlanResidual();timer.Stop();
  Check(visitedRows==3,"runtime cancellation stops new rows");Check(activeRows==0,"runtime cancellation drains running rows");Check(maxRows==1,"runtime cancellation remains single worker");Check(ZeitschleifeNonSteadyState.K==10,"partial cancelled count does not adjust K");Check(timer.Elapsed.TotalSeconds<1,"runtime cancellation returns within one second");
  results["cancel_during_planning"]=new {visited_rows=visitedRows,max_concurrent_rows=maxRows,final_k=ZeitschleifeNonSteadyState.K,elapsed_s=timer.Elapsed.TotalSeconds};
  results["checks_passed"]=checks;results["scope"]="Actual extracted PlanResidual with only test row-entry/exit witnesses. No production-source instrumentation.";
  File.WriteAllText(args[0],JsonSerializer.Serialize(results,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine("runtime checks "+checks);
 }
}
}
