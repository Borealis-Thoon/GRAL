"""Build and compare the minimal double-accumulation candidate on synthetic inputs."""
from __future__ import annotations
import argparse, csv, hashlib, json, math, os, re, shutil, signal, struct, subprocess, sys, time, zipfile
from pathlib import Path
NAMES=('warning_free_baseline','patchF_minimal')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value): path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def accumulation(text,double):
    field='Conz3dDouble' if double else 'Conz3d'
    a=text.index(('double' if double else 'float')+'[] conz3d_L = Program.'+field+'[iko][jko][II];')
    b=text.index('lock (conz3d_L)',a);b=text.index('{',b);e=text.index('}',b)+1
    return text[a:e]
def extracted(sources):
    body=['namespace Extracted { public static class Program { public static double[][][][] Conz3dDouble; public static float[][][][] Conz3d; } public static class Updates {']
    for variant,prefix in [('patchF_minimal',''),('warning_free_baseline','Old')]:
        for file,name in [('Zeitschleife.cs','New'),('Zeitschleife_nonsteadystate.cs','Residual')]:
            text=(sources[variant]/'src'/file).read_text(encoding='utf-8-sig')
            body+=['public static void '+prefix+name+'(double masse,float idt,int iko,int jko,int II,int SG_nteil) {',accumulation(text,variant=='patchF_minimal'),'}']
    return '\n'.join(body)+'\n} }\n'
def inspect(package,sources,inputs):
    manifest=json.loads((package/'reproduce/source_manifest.json').read_text(encoding='utf-8'))
    for name in NAMES:
        actual={p.relative_to(sources[name]).as_posix():sha(p) for p in sorted((sources[name]/'src').glob('*')) if p.is_file()}
        if actual!=manifest['sources'][name]:raise AssertionError('Frozen source differs: '+name)
    for name,expected in manifest['fixture_files'].items():
        if sha(package/'reproduce/fixture'/name)!=expected:raise AssertionError('Fixture hash differs: '+name)
    for n in (100,1000,3000):
        folder=inputs/f'budget{n}_fixed';record=json.loads((folder/'input_manifest.json').read_text())
        for file,item in record.items():
            if sha(folder/file)!=item['sha256']:raise AssertionError('Input hash differs: '+file)
    if extracted(sources)!=(package/'reproduce/fixture/AccumulationSnippets.cs').read_text(encoding='utf-8'):raise AssertionError('Compiled accumulation snippets differ from production source')
    candidate=(sources['patchF_minimal']/'src/Program.cs').read_text(encoding='utf-8-sig')
    if not candidate.index('TransferConcentrations();')<candidate.index('VolumeCorrection();'):raise AssertionError('Transfer must precede volume correction')
    for file in ('Write2DConcentrations.cs','Write3DConcentrations.cs','WriteTransientConcentrations.cs','WriteReceptorConcentrations.cs','Transient_Concentration.cs'):
        if sha(sources['patchF_minimal']/'src'/file)!=sha(sources['warning_free_baseline']/'src'/file):raise AssertionError('Protected source changed: '+file)
    return manifest

def process(command,cwd,env,timeout):
    option={'creationflags':getattr(subprocess,'CREATE_NO_WINDOW',0)} if os.name=='nt' else {'start_new_session':True}
    p=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**option)
    try:out,err=p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name=='nt':subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        else:os.killpg(p.pid,signal.SIGKILL)
        p.communicate(timeout=10);raise TimeoutError('Owned process exceeded its time limit')
    return p.returncode,out.decode('utf-8',errors='replace'),err.decode('utf-8',errors='replace')
def configure(folder,case):
    lines=(folder/'in.dat').read_text().splitlines();gral=(folder/'GRAL.geb').read_text().splitlines()
    lines[2]='1' if case['mode']=='stationary' else '0'
    if case['slices']==9:lines[9]='2 4 6 8 10 12 14 16 18';gral[5]='9'
    if case['receptors']:
        lines[4]='1';(folder/'Receptor.dat').write_text('2\n1,90,90,2,Near\n2,130,90,2,Far\n',encoding='utf-8')
    if case['deposition']:
        source=(folder/'cadastre.dat').read_text().splitlines();source=[source[0]]+[row+',100,100,30,0,0.02,0.02,0.02,1' for row in source[1:]];(folder/'cadastre.dat').write_text('\n'.join(source)+'\n',encoding='utf-8')
    if case['odour']:(folder/'Pollutant.txt').write_text('odour\n',encoding='utf-8')
    (folder/'Max_Proc.txt').write_text(str(case['workers'])+'\n',encoding='utf-8');(folder/'in.dat').write_text('\n'.join(lines)+'\n',encoding='utf-8');(folder/'GRAL.geb').write_text('\n'.join(gral)+'\n',encoding='utf-8')
    save(folder/'synthetic_case.json',case)
def outputs(folder,case):
    fields={};other={};counts={'deposition':0,'odour':0,'receptors':0,'checkpoints':0}
    for path in sorted(folder.glob('*.grz')):
        with zipfile.ZipFile(path) as archive:
            for name in sorted(archive.namelist()):
                raw=archive.read(name)
                if name.endswith('.con'):
                    h,x,y,dx,dy,nx,ny=struct.unpack_from('<iiiffii',raw)
                    if h!=-3 or nx!=case.get('nx',10) or ny!=case.get('ny',10) or len(raw)!=28+nx*ny*4:raise AssertionError('4-byte dense concentration format')
                    values=struct.unpack_from('<'+str(nx*ny)+'f',raw,28)
                    if not all(math.isfinite(v) and v>=0 for v in values):raise AssertionError('Finite nonnegative concentration')
                    fields[name]={'sha256':hashlib.sha256(raw).hexdigest(),'sum':math.fsum(values),'values':list(values)}
                elif name.endswith('.odr'):
                    other[name]=hashlib.sha256(raw).hexdigest();counts['odour']+=1
                    h,x,y,dx,dy,nx,ny=struct.unpack_from('<iiiffii',raw)
                    if h!=-3 or len(raw)!=28+nx*ny*16:raise AssertionError('Odour float payload format')
                    if not all(math.isfinite(v) and v>=0 for v in struct.unpack_from('<'+str(nx*ny*4)+'f',raw,28)):raise AssertionError('Odour finite nonnegative')
                elif name.endswith('.dep'):
                    other[name]=hashlib.sha256(raw).hexdigest();counts['deposition']+=1
                    h,x,y,dx,dy,nx,ny=struct.unpack_from('<iiiffii',raw)
                    if h!=-3 or len(raw)!=28+nx*ny*4:raise AssertionError('Deposition payload format')
                    if not all(math.isfinite(v) and v>=0 for v in struct.unpack_from('<'+str(nx*ny)+'f',raw,28)):raise AssertionError('Deposition finite nonnegative')
    expected=(3 if case['mode']=='transient' else 1)*case['slices']*2
    if len(fields)!=expected:raise AssertionError(f'Concentration count {len(fields)} differs from {expected}')
    for path in sorted(folder.glob('Transient_Concentrations*.tmp')):
        with zipfile.ZipFile(path) as archive:
            for name in sorted(archive.namelist()):other[path.name+':'+name]=hashlib.sha256(archive.read(name)).hexdigest();counts['checkpoints']+=1
    for pattern,kind in [('*.odr','odour'),('ReceptorConcentrations.dat','receptors'),('Receptor_Timeseries_Transient.txt','receptors')]:
        for path in sorted(folder.glob(pattern)):other[path.name]=sha(path);counts[kind]+=1
    if case['mode']=='transient' and counts['checkpoints']!=1:raise AssertionError('One residual checkpoint expected')
    if case['mode']=='stationary' and counts['checkpoints']!=0:raise AssertionError('Stationary must not store transient checkpoint')
    if case['receptors'] and counts['receptors']<1:raise AssertionError('Missing receptor outputs')
    if case['deposition'] and counts['deposition']!=6:raise AssertionError('Six deposition outputs expected')
    if case['odour'] and counts['odour']!=18:raise AssertionError('18 stationary odour outputs expected')
    return fields,other,counts

def metrics(a,b):
    av=[v for name in sorted(a) for v in a[name]['values']];bv=[v for name in sorted(b) for v in b[name]['values']]
    difference=math.fsum(abs(y-x) for x,y in zip(av,bv));denominator=math.fsum(abs(x) for x in av)
    ulps=[abs(struct.unpack('<I',struct.pack('<f',x))[0]-struct.unpack('<I',struct.pack('<f',y))[0]) for x,y in zip(av,bv)]
    return {'cells':len(av),'changed_cells':sum(x!=y for x,y in zip(av,bv)),'relative_l1':difference/denominator if denominator else 0,'max_absolute_difference':max(abs(y-x) for x,y in zip(av,bv)),'max_ulp':max(ulps),'baseline_sum':math.fsum(av),'candidate_sum':math.fsum(bv),'nonzero_support_difference':sum((x>0)!=(y>0) for x,y in zip(av,bv))}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--package-root',type=Path,default=Path(__file__).resolve().parents[1]);parser.add_argument('--source-root',type=Path);parser.add_argument('--input-root',type=Path);parser.add_argument('--run-dir',type=Path);parser.add_argument('--dotnet',default='dotnet');parser.add_argument('--check-only',action='store_true');args=parser.parse_args();package=args.package_root.resolve();source_root=(args.source_root or package/'sources').resolve();sources={name:source_root/name for name in NAMES};inputs=(args.input_root or package/'inputs/synthetic_templates').resolve();inspect(package,sources,inputs)
    if args.check_only:print('[PASS] source hashes, input hashes, exact snippets and protected writers');return
    if args.run_dir is None:parser.error('--run-dir is required')
    run=args.run_dir.resolve()
    if run.exists():raise FileExistsError('Use a new isolated run directory')
    if package==run or any(source==run or source in run.parents for source in sources.values()):raise ValueError('Run outside source checkouts')
    run.mkdir(parents=True)
    for name in ('logs','tmp','cache','qa'):(run/name).mkdir()
    env=os.environ.copy();env.update({'DOTNET_CLI_HOME':str(run/'cache/dotnet_home'),'NUGET_PACKAGES':str(run/'cache/nuget'),'TEMP':str(run/'tmp'),'TMP':str(run/'tmp'),'DOTNET_CLI_UI_LANGUAGE':'en','DOTNET_NOLOGO':'1'})
    dotnet=str(Path(args.dotnet).resolve()) if Path(args.dotnet).is_file() else shutil.which(args.dotnet)
    if dotnet is None:raise FileNotFoundError('Verified .NET CLI required')
    started=time.perf_counter();builds={}
    def limit(seconds):
        remaining=900-(time.perf_counter()-started)
        if remaining<=0:raise TimeoutError('15-minute suite limit')
        return min(seconds,remaining)
    def build(project,label):
        code,out,err=process([dotnet,'build',str(project),'-c','Release','-t:Rebuild','-v:minimal','--nologo','/p:TreatWarningsAsErrors=true'],project.parent,env,limit(180));log=out+err;(run/'logs'/(label+'_build.log')).write_text(log,encoding='utf-8');w=re.search(r'(\d+) Warning\(s\)',log);e=re.search(r'(\d+) Error\(s\)',log)
        if code or not w or not e or int(w.group(1)) or int(e.group(1)):raise RuntimeError('Strict build '+label+' failed')
        builds[label]={'warnings':0,'errors':0};print('[BUILD] '+label+' 0 0',flush=True)
    variant_copies={}
    for name in NAMES:
        target=run/'sources'/name;shutil.copytree(sources[name],target,ignore=shutil.ignore_patterns('bin','obj','.git'));variant_copies[name]=target;build(target/'src/GRAL.csproj',name)
    fixture=run/'fixture';shutil.copytree(package/'reproduce/fixture',fixture,ignore=shutil.ignore_patterns('bin','obj'));build(fixture/'PrecisionFixture.csproj','precision_fixture');fixture_json=run/'qa/precision_fixture.json';fixture_output=run/'fixture_outputs'
    code,out,err=process([dotnet,str(fixture/'bin/Release/net10.0/PrecisionFixture.dll'),str(variant_copies['patchF_minimal']/'src/bin/Release/net10.0/GRAL.dll'),str(fixture_json),str(fixture_output)],fixture,env,limit(120));(run/'logs/fixture.log').write_text(out+err,encoding='utf-8')
    if code:raise RuntimeError('Precision fixture failed: '+out+err)
    helper=json.loads(fixture_json.read_text());print('[FIXTURE] '+str(helper['checks_passed']),flush=True)
    conditions=[]
    for mode in ('stationary','transient'):
        for n in (100,1000,3000):conditions.append({'id':f'{mode}_n{n}','mode':mode,'budget':n,'slices':1,'workers':1,'receptors':False,'deposition':False,'odour':False})
    conditions += [{'id':'stationary_multislice_receptors','mode':'stationary','budget':1000,'slices':9,'workers':1,'receptors':True,'deposition':False,'odour':False},{'id':'transient_deposition_receptors','mode':'transient','budget':1000,'slices':1,'workers':1,'receptors':True,'deposition':True,'odour':False},{'id':'stationary_odour_two_workers','mode':'stationary','budget':1000,'slices':9,'workers':2,'receptors':False,'deposition':False,'odour':True}]
    runs=[];run_map={};index=0
    for case in conditions:
        for name in NAMES:
            for repeat in (1,2):
                index+=1;rid=case['id']+'_'+name+'_r'+str(repeat);folder=run/'virtual_runs'/rid;shutil.copytree(inputs/f"budget{case['budget']}_fixed",folder);configure(folder,case)
                t=time.perf_counter();code,out,err=process([dotnet,str(variant_copies[name]/'src/bin/Release/net10.0/GRAL.dll'),str(folder)],folder,env,limit(60));elapsed=time.perf_counter()-t;(folder/'console.log').write_text(out,encoding='utf-8');(folder/'stderr.log').write_text(err,encoding='utf-8');core=folder/'Logfile_GRALCore.txt';problem=folder/'Problemreport_GRAL.txt'
                if code or not core.exists() or 'GRAL simulations finished at:' not in core.read_text(encoding='utf-8-sig') or (problem.exists() and problem.read_text(encoding='utf-8-sig').strip()):raise AssertionError('Actual Main completion failed '+rid)
                fields,other,counts=outputs(folder,case);allocations=list(map(int,re.findall(r'Using a total of (\d+) particles',out)))
                if allocations!=[case['budget']]:raise AssertionError('Configured allocation mismatch '+rid)
                mass_matches=re.findall(r'Summarized emission rates per source group in kg\s*\n([^\n]+)\n([^\n]+)',out);mass=mass_matches[-1][1].split() if mass_matches else []
                if case['mode']=='transient' and (len(mass)!=2 or not math.isclose(float(mass[0]),30/3600,rel_tol=.006) or not math.isclose(float(mass[1]),60/3600,rel_tol=.006)):raise AssertionError('Reported transient fresh mass differs from configured source schedule')
                record={'run_id':rid,'case':case,'variant':name,'repeat':repeat,'elapsed_s':elapsed,'checks_passed':8,'checks':{'exit_zero':True,'completion_marker':True,'empty_problem_report':True,'concentration_count':True,'float32_format':True,'finite_nonnegative':True,'configured_allocation':True,'expected_auxiliary_outputs':True},'counts':counts,'field_payloads':{k:{q:v for q,v in item.items() if q!='values'} for k,item in fields.items()},'other_payloads':other,'fresh_mass_text':mass};runs.append(record);run_map[(case['id'],name,repeat)]=(fields,other,record);print(f'[RUN] {index}/36 {rid}',flush=True)
    comparisons=[];repeat_results=[]
    for case in conditions:
        for name in NAMES:
            f1,o1,r1=run_map[(case['id'],name,1)];f2,o2,r2=run_map[(case['id'],name,2)];same_fields=all(f1[k]['sha256']==f2[k]['sha256'] for k in f1);same_other=o1==o2
            if case['workers']==1 and (not same_fields or not same_other):raise AssertionError('Single-worker fixed-repeat differs '+case['id']+' '+name)
            repeat_results.append({'case':case['id'],'variant':name,'workers':case['workers'],'same_concentration_payloads':same_fields,'same_other_payloads':same_other,'required_bitwise':case['workers']==1})
        for repeat in (1,2):
            a,oa,ra=run_map[(case['id'],NAMES[0],repeat)];b,ob,rb=run_map[(case['id'],NAMES[1],repeat)];protected={k:oa[k]==ob.get(k) for k in oa if not k.endswith('.odr')}
            if case['workers']==1 and (not all(protected.values()) or ra['fresh_mass_text']!=rb['fresh_mass_text']):raise AssertionError('Protected output differs '+case['id'])
            comparisons.append({'case':case['id'],'mode':case['mode'],'budget':case['budget'],'workers':case['workers'],'repeat':repeat,**metrics(a,b),'protected_payloads_equal':all(protected.values()),'protected_payload_count':len(protected),'odour_payloads_equal':all(v==ob.get(k) for k,v in oa.items() if k.endswith('.odr')),'fresh_mass_equal':ra['fresh_mass_text']==rb['fresh_mass_text'] if ra['fresh_mass_text'] and rb['fresh_mass_text'] else None})
    summary={'status':'pass','strict_builds':builds,'main_runs':36,'main_checks_passed':288,'conditions':9,'single_worker_repeat_pairs':16,'multiworker_repeat_pairs':2,'concentration_payloads':sum(len(r['field_payloads']) for r in runs),'checkpoint_payloads':sum(r['counts']['checkpoints'] for r in runs),'transient_reported_fresh_mass_checked_runs':16,'protected_payload_pairs_equal':sum(x['protected_payload_count'] for x in comparisons if x['workers']==1),'frozen_source_files_per_variant':85,'helper_checks_passed':helper['checks_passed'],'elapsed_s':time.perf_counter()-started,'comparisons':comparisons,'repeat_results':repeat_results,'runs':runs,'limits':['Synthetic numerical and compatibility validation only; no true atmospheric concentration reference.','Two-worker ordering can vary; bitwise reproducibility is required only with one worker.','No production-domain peak memory or throughput claim.','The stored float output range and final rounding remain unchanged.','Fresh-emission totals are reported and checked only in transient Main runs; stationary Main does not report this diagnostic.','Managed memory measurements cover the same jagged concentration-array shape in the compiled fixture, not total process peak memory.']};save(run/'qa/validation_summary.json',summary)
    with (run/'qa/validation_output_comparison.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(comparisons[0]));writer.writeheader();writer.writerows(comparisons)
    with (run/'qa/validation_precision_stress.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(helper['precision_stress'][0]));writer.writeheader();writer.writerows(helper['precision_stress'])
    inspect(package,sources,inputs);print('[PASS] 36 Main runs; '+str(helper['checks_passed'])+' helper checks',flush=True)
if __name__=='__main__':main()