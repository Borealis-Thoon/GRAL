using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
using System.Threading.Tasks;
using System.Globalization;

class Fixture
{
    static int checks;
    static List<string> names = new();
    static void Check(bool valid,string label) { if(!valid) throw new Exception(label); checks++; names.Add(label); }
    static T[][][][] Array4<T>(int x,int y,int z,int g) { var a=new T[x][][][]; for(int i=0;i<x;i++){a[i]=new T[y][][];for(int j=0;j<y;j++){a[i][j]=new T[z][];for(int k=0;k<z;k++)a[i][j][k]=new T[g];}}return a; }
    static float[][] Array2(int x,int y,float value) { var a=new float[x][];for(int i=0;i<x;i++){a[i]=new float[y];Array.Fill(a[i],value);}return a; }
    static Type program = null!;
    static Type writers = null!;
    static void Set(string field,object value) { var f=program.GetField(field,BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic)!; if(!f.FieldType.IsAssignableFrom(value.GetType())) value=Convert.ChangeType(value,f.FieldType,CultureInfo.InvariantCulture);f.SetValue(null,value); }
    static object Get(string field) => program.GetField(field,BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic)!.GetValue(null)!;
    static void Call(string method) => program.GetMethod(method,BindingFlags.Static|BindingFlags.NonPublic|BindingFlags.Public)!.Invoke(null,null);
    static byte[] Binary(string method,int header,int ioutput) {
        Set("ResultFileHeader",header);Set("IOUTPUT",ioutput);
        using var ms=new MemoryStream();using(var bw=new BinaryWriter(ms,System.Text.Encoding.UTF8,true)) Check((bool)writers.GetMethod(method,BindingFlags.Static|BindingFlags.NonPublic)!.Invoke(null,new object[]{bw,0,0})!,"writer returns true "+method+" "+ioutput);
        return ms.ToArray();
    }
    static float[] Decode(byte[] bytes,int header,bool sound=false) {
        using var br=new BinaryReader(new MemoryStream(bytes));var result=new List<float>();
        if(sound){while(br.BaseStream.Position<br.BaseStream.Length){br.ReadInt32();br.ReadInt32();result.Add(br.ReadSingle());}return result.ToArray();}
        Check(br.ReadInt32()==header,"binary header "+header);
        if(header==-1){while(br.BaseStream.Position<br.BaseStream.Length){br.ReadInt32();br.ReadInt32();result.Add(br.ReadSingle());}}
        else if(header==-2){br.ReadInt32();br.ReadInt32();br.ReadSingle();br.ReadSingle();while(true){int n=br.ReadInt32();if(n==-1)break;br.ReadInt32();br.ReadInt32();for(int i=0;i<n;i++)result.Add(br.ReadSingle());}}
        else {br.ReadInt32();br.ReadInt32();br.ReadSingle();br.ReadSingle();Check(br.ReadInt32()==2&&br.ReadInt32()==2,"dense dimensions");while(br.BaseStream.Position<br.BaseStream.Length)result.Add(br.ReadSingle());}
        Check(br.BaseStream.Position==bytes.Length,"4 byte payload reaches end "+header);return result.ToArray();
    }
    static void Main(string[] args) {
        var assembly=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.GetFullPath(args[0]));program=assembly.GetType("GRAL_2001.Program")!;writers=assembly.GetType("GRAL_2001.ProgramWriters")!;
        var result=new Dictionary<string,object>();var stress=new List<object>();
        foreach(int n in new[]{100,1000,3000,1000000}) foreach(string scenario in new[]{"unit_tiny","large_unit","subnormal"}) foreach(int site in new[]{0,1}) {
            double start=scenario=="unit_tiny"?1:scenario=="large_unit"?16777216:0;
            double increment=scenario=="unit_tiny"?Math.ScaleB(1,-26):scenario=="large_unit"?1:(double)float.Epsilon/4;
            var candidate=Array4<double>(1,1,1,1);var baseline=Array4<float>(1,1,1,1);candidate[0][0][0][0]=start;baseline[0][0][0][0]=(float)start;
            Extracted.Program.Conz3dDouble=candidate;Extracted.Program.Conz3d=baseline;
            for(int i=0;i<n;i++){if(site==0){Extracted.Updates.New(increment,1,0,0,0,0);Extracted.Updates.OldNew(increment,1,0,0,0,0);}else{Extracted.Updates.Residual(increment,1,0,0,0,0);Extracted.Updates.OldResidual(increment,1,0,0,0,0);}}
            double exact=start+n*increment;float old=baseline[0][0][0][0],newvalue=(float)candidate[0][0][0][0],reference=(float)exact;
            Check(candidate[0][0][0][0]==exact,"exact binary rational double "+scenario+" "+n+" "+site);
            Check(BitConverter.SingleToInt32Bits(newvalue)==BitConverter.SingleToInt32Bits(reference),"round once reference "+scenario+" "+n+" "+site);
            Check(old!=reference,"float stagnation witnessed "+scenario+" "+n+" "+site);
            stress.Add(new{scenario,contributions=n,site=site==0?"new":"residual",exact,old_output=old,new_output=newvalue,old_absolute_error=Math.Abs((double)old-exact),new_absolute_error=Math.Abs((double)newvalue-exact),reference_float=reference});
        }
        result["precision_stress"]=stress;
        Set("NXL",2);Set("NYL",2);Set("NS",9);Set("SourceGroups",new List<int>{1,32,99});
        var d=Array4<double>(4,4,9,3);var f=Array4<float>(4,4,9,3);var plus=Array4<float>(4,4,9,3);var minus=Array4<float>(4,4,9,3);
        for(int i=0;i<4;i++)for(int j=0;j<4;j++)for(int k=0;k<9;k++)for(int g=0;g<3;g++){d[i][j][k][g]=(i+j+k+g)%5==0?0:1+Math.ScaleB(i*108+j*27+k*3+g,-25);f[i][j][k][g]=-42;plus[i][j][k][g]=17;minus[i][j][k][g]=19;}
        Set("Conz3d",f);Set("Conz3dDouble",d);Set("Conz3dp",plus);Set("Conz3dm",minus);Set("Depo_conz",new double[][][]{new double[][]{new double[]{23}}});Set("ReceptorConc",new double[][]{new double[]{29}});
        Call("TransferConcentrations");bool transferred=true,reset=true;for(int i=0;i<4;i++)for(int j=0;j<4;j++)for(int k=0;k<9;k++)for(int g=0;g<3;g++){float expected=(i+j+k+g)%5==0?0:(float)(1+Math.ScaleB(i*108+j*27+k*3+g,-25));transferred&=BitConverter.SingleToInt32Bits(f[i][j][k][g])==BitConverter.SingleToInt32Bits(expected);reset&=d[i][j][k][g]==0;}
        Check(transferred,"all 432 padded cells SG and slices transferred incl zero");Check(reset,"all double cells reset");Check(plus[3][3][8][2]==17&&minus[3][3][8][2]==19&&((double[][][])Get("Depo_conz"))[0][0][0]==23&&((double[][])Get("ReceptorConc"))[0][0]==29,"transfer preserves odour deposition receptor arrays");
        d[1][1][4][1]=3.25;Call("TransferConcentrations");Check(f[1][1][4][1]==3.25F&&f[3][3][8][2]==0,"second situation overwrites prior concentrations and clears");
        var parallel=Array4<double>(1,1,1,1);Extracted.Program.Conz3dDouble=parallel;Parallel.For(0,100000,new ParallelOptions{MaxDegreeOfParallelism=4},i=>{if(i%2==0)Extracted.Updates.New(1,1,0,0,0,0);else Extracted.Updates.Residual(1,1,0,0,0,0);});Check(parallel[0][0][0][0]==100000,"shared new residual leaf lock loses no contributions with 4 workers");
        var memory=new List<object>();Array4<double>(4,4,1,2);Array4<float>(4,4,1,2);
        foreach(int ns in new[]{1,9})foreach(int sg in new[]{2,32,99}){long before=GC.GetAllocatedBytesForCurrentThread();var af=Array4<float>(12,12,ns,sg);long floatBytes=GC.GetAllocatedBytesForCurrentThread()-before;before=GC.GetAllocatedBytesForCurrentThread();var ad=Array4<double>(12,12,ns,sg);long extra=GC.GetAllocatedBytesForCurrentThread()-before;GC.KeepAlive(af);GC.KeepAlive(ad);long entries=144L*ns*sg;Check(extra>=8*entries,"measured managed double memory includes payload "+ns+" "+sg);memory.Add(new{nxl=10,nyl=10,ns,source_groups=sg,entries,float_array_managed_bytes=floatBytes,added_double_managed_bytes=extra,added_double_payload_bytes=8*entries,total_normal_managed_bytes=floatBytes+extra});}result["memory_allocations"]=memory;
        Set("NS",1);Set("SourceGroups",new List<int>{1});Set("NXL",2);Set("NYL",2);Set("NII",4);Set("NJJ",4);Set("GralDx",20F);Set("GralDy",20F);Set("GralDz",4F);Set("GridVolume",1600F);Set("HorSlices",new float[]{2});Set("BuildingsExist",true);Set("ReceptorsAvailable",false);Set("Odour",false);
        ((ParallelOptions)Get("pOptions")).MaxDegreeOfParallelism=1;
        foreach(int flow in new[]{10,20}) {
            Set("DXK",flow);Set("DYK",flow);Set("BUI_HEIGHT",Array2(6,6,1));var vd=Array4<double>(4,4,1,1);var vf=Array4<float>(4,4,1,1);
            for(int i=0;i<4;i++)for(int j=0;j<4;j++)vd[i][j][0][0]=1+Math.ScaleB(3,-25);Set("Conz3d",vf);Set("Conz3dDouble",vd);Call("TransferConcentrations");float pre=vf[1][1][0][0];Call("VolumeCorrection");float factor=4F/3F;Check(vf[1][1][0][0]==pre*factor,"existing float building correction remains after transfer flow "+flow);Check(vd[1][1][0][0]==0,"building correction does not restore double values "+flow);
        }
        Set("BuildingsExist",false);Set("IKOOAGRAL",0);Set("JKOOAGRAL",0);Set("GralWest",0D);Set("GralSouth",0D);Set("WriteASCiiResults",false);Set("DepositionExist",false);Set("WetDeposition",false);Set("NS",1);Set("SourceGroups",new List<int>{1});
        Set("Depo_conz",Enumerable.Range(0,4).Select(i=>Enumerable.Range(0,4).Select(j=>new double[1]).ToArray()).ToArray()); var wf=Array4<float>(4,4,1,1);wf[1][1][0][0]=1.25F;wf[1][2][0][0]=0;wf[2][1][0][0]=float.Epsilon;wf[2][2][0][0]=17.5F;Set("Conz3d",wf);
        var nonzero=new float[]{1.25F,float.Epsilon,17.5F};var all=new float[]{1.25F,0,float.Epsilon,17.5F};var writerChecks=new List<object>();
        foreach(var pair in new[]{(-1,"WriteConcentrationData"),(-2,"WriteConcentrationDataStrongCompressed"),(-3,"WriteConcentrationDataAllCompressed")}){var bytes=Binary(pair.Item2,pair.Item1,0);Check(Decode(bytes,pair.Item1).SequenceEqual(pair.Item1==-3?all:nonzero),"writer preserves float values "+pair.Item1);writerChecks.Add(new{header=pair.Item1,bytes=bytes.Length,expected_float_bytes=4});}
        var sound=Binary("WriteConcentrationData",-1,1);Check(sound.Length==48&&Decode(sound,-1,true).SequenceEqual(all),"SOUNDPLAN 12-byte records preserve float payload");
        Directory.CreateDirectory(args[2]);Directory.SetCurrentDirectory(args[2]);Set("IOUTPUT",0);
        Check((bool)writers.GetMethod("writeConDataAscii",BindingFlags.NonPublic|BindingFlags.Static)!.Invoke(null,new object[]{"ascii.con",0,0})!,"ASCII writer returns true");var rows=File.ReadAllLines("ascii.txt").Skip(6).SelectMany(x=>x.Split(' ',StringSplitOptions.RemoveEmptyEntries)).Select(x=>float.Parse(x,CultureInfo.InvariantCulture)).ToArray();Check(rows.SequenceEqual(new float[]{0,17.5F,1.25F,float.Epsilon}),"ASCII float text round trips incl subnormal");
        foreach(int header in new[]{-1,-2,-3}){wf[1][1][0][0]=1.25F;wf[1][2][0][0]=0;wf[2][1][0][0]=float.Epsilon;wf[2][2][0][0]=17.5F;Set("ResultFileZipped",true);Set("ResultFileHeader",header);string zip="format"+header+".grz";var instance=Activator.CreateInstance(writers)!;writers.GetMethod("Write2DConcentrations")!.Invoke(instance,new object[]{1,zip});using var archive=ZipFile.OpenRead(zip);Check(archive.Entries.Count==1,"zipped writer one concentration "+header);using var ms=new MemoryStream();using(var s=archive.Entries[0].Open())s.CopyTo(ms);Check(Decode(ms.ToArray(),header).SequenceEqual(header==-3?all:nonzero),"zipped payload matches 4-byte float format "+header);}
        wf[1][1][0][0]=1.25F;wf[1][2][0][0]=0;wf[2][1][0][0]=float.Epsilon;wf[2][2][0][0]=17.5F;Set("ResultFileZipped",false);Set("ResultFileHeader",-1);writers.GetMethod("Write2DConcentrations")!.Invoke(Activator.CreateInstance(writers),new object[]{2,"unused.grz"});Check(Decode(File.ReadAllBytes("00002-101.con"),-1).SequenceEqual(nonzero),"plain writer float payload");result["writer_formats"]=writerChecks;
        result["status"]="pass";result["checks_passed"]=checks;result["checks"]=names;result["runtime"]=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription;
        File.WriteAllText(args[1],JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine("[PASS] "+checks);
    }
}