namespace Extracted { public static class Program { public static double[][][][] Conz3dDouble; public static float[][][][] Conz3d; } public static class Updates {
public static void New(double masse,float idt,int iko,int jko,int II,int SG_nteil) {
double[] conz3d_L = Program.Conz3dDouble[iko][jko][II];
                            double conc = masse * idt;
                            lock (conz3d_L)
                            {
                                conz3d_L[SG_nteil] += conc;
                            }
}
public static void Residual(double masse,float idt,int iko,int jko,int II,int SG_nteil) {
double[] conz3d_L = Program.Conz3dDouble[iko][jko][II];
                            double conc = masse * idt;
                            lock (conz3d_L)
                            {
                                conz3d_L[SG_nteil] += conc;
                            }
}
public static void OldNew(double masse,float idt,int iko,int jko,int II,int SG_nteil) {
float[] conz3d_L = Program.Conz3d[iko][jko][II];
                            double conc = masse * idt;
                            lock (conz3d_L)
                            {
                                conz3d_L[SG_nteil] += (float)conc;
                            }
}
public static void OldResidual(double masse,float idt,int iko,int jko,int II,int SG_nteil) {
float[] conz3d_L = Program.Conz3d[iko][jko][II];
                            double conc = masse * idt;
                            lock (conz3d_L)
                            {
                                conz3d_L[SG_nteil] += (float)conc;
                            }
}
} }
