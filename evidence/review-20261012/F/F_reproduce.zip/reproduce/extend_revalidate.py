"""Rerun the frozen 36-run suite, then vary meteorology and horizontal resolution."""
from __future__ import annotations
import argparse, csv, hashlib, json, math, os, re, shutil, struct, sys, time, zipfile
from pathlib import Path
import revalidate as base

def conditions():
    cases=[]
    specs=[('day_stationary_10m_n100','stationary',100,10,2.5,2,[9]),
           ('day_transient_10m_n1000','transient',1000,10,2.5,2,[9,18,27]),
           ('day_stationary_40m_n3000','stationary',3000,40,2.5,2,[18]),
           ('stable_transient_40m_n100','transient',100,40,.5,6,[27,18,9]),
           ('stable_stationary_10m_n1000','stationary',1000,10,.5,6,[27]),
           ('stable_transient_40m_n3000','transient',3000,40,.5,6,[18,27,9])]
    for ident,mode,n,dx,speed,stability,dirs in specs:
        cases.append(dict(id=ident,mode=mode,budget=n,slices=1,workers=1,receptors=False,deposition=False,odour=False,
                          dx=dx,dy=dx,nx=200//dx,ny=200//dx,wind_speed=speed,stability=stability,directions=dirs,
                          domain_extent_m=[0,200,0,200],situation_duration_s=30,weather_situations=len(dirs)))
    return cases

def configure(folder,case):
    base.configure(folder,case)
    lines=(folder/'GRAL.geb').read_text(encoding='utf-8').splitlines()
    for index,value in [(0,case['dx']),(1,case['dy']),(3,case['nx']),(4,case['ny'])]:lines[index]=str(value)
    (folder/'GRAL.geb').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    met=['10,1,10','wind_dir,wind_speed,stability,frequency']+[f"{d},{case['wind_speed']},{case['stability']},1" for d in case['directions']]
    (folder/'meteopgt.all').write_text('\n'.join(met)+'\n',encoding='utf-8')
    series=[f"01.01.2022 {h:02d} {case['wind_speed']} {d} {case['stability']}" for h,d in enumerate(case['directions'])]
    (folder/'mettimeseries.dat').write_text('\n'.join(series)+'\n',encoding='utf-8')
    declared=(folder/'GRAL.geb').read_text(encoding='utf-8').splitlines()
    if len(declared)!=11 or tuple(map(float,declared[7:11]))!=(0,200,0,200):raise AssertionError('Domain extent format')
    if tuple(map(int,declared[3:5]))!=(case['nx'],case['ny']):raise AssertionError('Concentration cell declaration')
    if not all(math.isclose(float(declared[i]),case['dx']) for i in (0,1)):raise AssertionError('Flowfield resolution declaration')
    if not math.isclose(200/case['nx'],case['dx']):raise AssertionError('Physical resolution mismatch')
    spec=json.loads((folder/'fixture_spec.json').read_text(encoding='utf-8'))
    spec.update(steady=case['mode']=='stationary',temporal=case['mode']=='transient',
                physical_field_extent_m=case['domain_extent_m'],concentration_cells=[case['nx'],case['ny']],
                horizontal_flowfield_resolution_m=case['dx'],horizontal_concentration_resolution_m=case['dx'],
                wind_speed_m_s=case['wind_speed'],stability_class=case['stability'],
                wind_directions_deg=[d*10 for d in case['directions']],weather_situations=case['weather_situations'],
                interpretation='Each synthetic situation integrates for 30 seconds. Hour labels only index inputs. Wind and stability class are prescribed; radiation is not resolved.')
    base.save(folder/'fixture_spec.json',spec)
    base.save(folder/'synthetic_case.json',case)
    manifest={p.name:{'size':p.stat().st_size,'sha256':base.sha(p)} for p in sorted(folder.iterdir()) if p.is_file() and p.name not in ('input_manifest.json','configured_input_manifest.json')}
    base.save(folder/'input_manifest.json',manifest)
    base.save(folder/'configured_input_manifest.json',manifest)

def weather_check(console,case):
    found=re.findall(r'Init meteo:\s+wind speed \[m/s\]: ([0-9.]+)\s+direction \[deg\]: ([0-9]+)\s+Stability class \[-\]: ([0-9]+)',console)
    actual=[(float(speed),int(direction),int(stability)) for speed,direction,stability in found]
    expected=[(case['wind_speed'],d*10,case['stability']) for d in case['directions']]
    if actual!=expected:raise AssertionError('Actual meteorology mismatch: '+repr(actual)+' != '+repr(expected))
    return actual

def grid_check(folder,case):
    checked=0;floats=0
    for archive_path in folder.glob('*.grz'):
        with zipfile.ZipFile(archive_path) as archive:
            for name in archive.namelist():
                if not name.endswith('.con'):continue
                raw=archive.read(name);h,x,y,dx,dy,nx,ny=struct.unpack_from('<iiiffii',raw)
                if (h,x,y,nx,ny)!=(-3,0,0,case['nx'],case['ny']):raise AssertionError('Dynamic grid header mismatch')
                if not (math.isclose(dx,case['dx']) and math.isclose(dy,case['dy'])):raise AssertionError('Output horizontal resolution mismatch')
                if len(raw)!=28+nx*ny*4:raise AssertionError('Float payload width mismatch')
                checked+=1;floats+=nx*ny
    return checked,floats

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package-root',type=Path,default=Path(__file__).resolve().parents[1]);parser.add_argument('--run-dir',type=Path,required=True)
    parser.add_argument('--dotnet',default='dotnet');args=parser.parse_args();package=args.package_root.resolve();run=args.run_dir.resolve()
    if run.exists():raise FileExistsError('Use a new isolated run directory')
    sources={name:package/'sources'/name for name in base.NAMES};inputs=package/'inputs/synthetic_templates';base.inspect(package,sources,inputs)
    if package==run or package in run.parents:raise ValueError('Run outside package')
    run.mkdir(parents=True);started=time.perf_counter()
    code,out,err=base.process([sys.executable,'-X','utf8','-B',str(package/'reproduce/revalidate.py'),'--package-root',str(package),'--run-dir',str(run/'prior'),'--dotnet',args.dotnet],package,os.environ.copy(),850)
    (run/'prior_suite_console.log').write_text(out+err,encoding='utf-8')
    if code:raise RuntimeError('Frozen suite failed: '+out+err)
    prior=json.loads((run/'prior/qa/validation_summary.json').read_text(encoding='utf-8'))
    print(f"[PRIOR] {prior['main_runs']} Main; {prior['helper_checks_passed']} fixture; strict 0 0",flush=True)
    extended=run/'extended'
    for name in ('logs','tmp','cache','qa','inputs'):(extended/name).mkdir(parents=True)
    env=os.environ.copy();env.update({'DOTNET_CLI_HOME':str(extended/'cache/dotnet_home'),'NUGET_PACKAGES':str(extended/'cache/nuget'),'TEMP':str(extended/'tmp'),'TMP':str(extended/'tmp'),'DOTNET_CLI_UI_LANGUAGE':'en','DOTNET_NOLOGO':'1'})
    dotnet=str(Path(args.dotnet).resolve()) if Path(args.dotnet).is_file() else shutil.which(args.dotnet)
    if dotnet is None:raise FileNotFoundError('Verified dotnet CLI required')
    runs=[];records={};payloads=0;floats=0
    for case in conditions():
        template=extended/'inputs'/case['id'];shutil.copytree(inputs/f"budget{case['budget']}_fixed",template);configure(template,case)
        for name in base.NAMES:
            for repeat in (1,2):
                remaining=900-(time.perf_counter()-started)
                if remaining<=0:raise TimeoutError('Whole suite exceeded 15-minute budget')
                ident=f"{case['id']}_{name}_r{repeat}";folder=extended/'virtual_runs'/ident;shutil.copytree(template,folder)
                t=time.perf_counter();code,out,err=base.process([dotnet,str(run/'prior/sources'/name/'src/bin/Release/net10.0/GRAL.dll'),str(folder)],folder,env,min(60,remaining))
                (folder/'console.log').write_text(out,encoding='utf-8');(folder/'stderr.log').write_text(err,encoding='utf-8')
                core=folder/'Logfile_GRALCore.txt';problem=folder/'Problemreport_GRAL.txt'
                if code or not core.exists() or 'GRAL simulations finished at:' not in core.read_text(encoding='utf-8-sig') or (problem.exists() and problem.read_text(encoding='utf-8-sig').strip()):raise AssertionError('Actual Main completion '+ident)
                actual_weather=weather_check(out,case);fields,other,counts=base.outputs(folder,case);count,n_float=grid_check(folder,case)
                allocation=list(map(int,re.findall(r'Using a total of (\d+) particles',out)))
                if allocation!=[case['budget']]:raise AssertionError('Particle allocation mismatch '+ident)
                if count!=case['weather_situations']*2:raise AssertionError('Dynamic output count '+ident)
                checks={k:True for k in ('exit_zero','completion_marker','empty_problem_report','float32_format','finite_nonnegative','configured_allocation','expected_auxiliary_outputs','concentration_count','domain_extent_200m','declared_flowfield_resolution','declared_concentration_cells','output_horizontal_resolution','output_dynamic_grid_cells','actual_meteorology_sequence','within_60_second_main_limit')}
                item=dict(run_id=ident,case=case,variant=name,repeat=repeat,elapsed_s=time.perf_counter()-t,checks_passed=len(checks),checks=checks,actual_weather=actual_weather,counts=counts,concentration_payloads=count,float_values_checked=n_float,field_payloads={k:{q:v for q,v in item.items() if q!='values'} for k,item in fields.items()},other_payloads=other)
                runs.append(item);records[(case['id'],name,repeat)]=(fields,other,item);payloads+=count;floats+=n_float
                print(f'[EXTRA] {len(runs)}/24 {ident}',flush=True)
    repeat_results=[];comparisons=[]
    for case in conditions():
        for name in base.NAMES:
            f1,o1,r1=records[(case['id'],name,1)];f2,o2,r2=records[(case['id'],name,2)]
            if not all(f1[k]['sha256']==f2[k]['sha256'] for k in f1) or o1!=o2:raise AssertionError('Single-worker repeat mismatch '+case['id']+' '+name)
            repeat_results.append(dict(case=case['id'],variant=name,same_concentration_payloads=True,same_other_payloads=True))
        for repeat in (1,2):
            a,oa,ra=records[(case['id'],base.NAMES[0],repeat)];b,ob,rb=records[(case['id'],base.NAMES[1],repeat)]
            if oa!=ob:raise AssertionError('Protected checkpoint mismatch '+case['id'])
            comparisons.append(dict(case=case['id'],mode=case['mode'],budget=case['budget'],resolution_m=case['dx'],wind_speed_m_s=case['wind_speed'],stability_class=case['stability'],repeat=repeat,**base.metrics(a,b),protected_payloads_equal=True,protected_payload_count=len(oa)))
    summary=dict(status='pass',prior_rerun=dict(main_runs=prior['main_runs'],main_checks_passed=prior['main_checks_passed'],helper_checks_passed=prior['helper_checks_passed'],strict_builds=prior['strict_builds'],single_worker_repeat_pairs=prior['single_worker_repeat_pairs'],multiworker_repeat_pairs=prior['multiworker_repeat_pairs'],concentration_payloads=prior['concentration_payloads'],elapsed_s=prior['elapsed_s']),additional=dict(main_runs=len(runs),main_checks_passed=sum(r['checks_passed'] for r in runs),conditions=len(conditions()),single_worker_repeat_pairs=len(repeat_results),concentration_payloads=payloads,float_values_checked=floats,checkpoint_payloads=sum(r['counts']['checkpoints'] for r in runs),protected_payload_pairs_equal=sum(r['protected_payload_count'] for r in comparisons),actual_meteorology_checked_runs=len(runs),domain_extent_m=[0,200,0,200],resolutions_m=[10,40]),total_main_runs=prior['main_runs']+len(runs),total_main_checks_passed=prior['main_checks_passed']+sum(r['checks_passed'] for r in runs),helper_checks_passed=prior['helper_checks_passed'],elapsed_s=time.perf_counter()-started,conditions=conditions(),runs=runs,comparisons=comparisons,repeat_results=repeat_results,limits=['The added weather cases specify wind and stability class; they are not a radiation-resolving daytime model.','Three transient situations each integrate for 30 seconds; hourly fixture labels do not represent three hours of physical integration.','Output differences quantify numerical storage changes; there is no independent true atmospheric concentration reference.','Single-worker fixed-seed repeatability applies to these controlled cases only.','Cases balance cost and coverage; they are not a full factorial design and do not isolate individual meteorology, resolution or particle-budget effects.','No production-domain throughput or total peak-memory claim.'])
    base.save(extended/'qa/extended_validation_summary.json',summary)
    with (extended/'qa/extended_output_comparison.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(comparisons[0]));writer.writeheader();writer.writerows(comparisons)
    base.inspect(package,sources,inputs)
    print(f"[PASS] {summary['total_main_runs']} Main; {summary['total_main_checks_passed']} Main checks; {summary['helper_checks_passed']} fixture checks",flush=True)
if __name__=='__main__':main()
